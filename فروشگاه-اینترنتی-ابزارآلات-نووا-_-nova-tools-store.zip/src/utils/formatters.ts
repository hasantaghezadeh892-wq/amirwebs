/**
 * Convert English digits to Persian digits
 */
export function toPersianDigits(n: number | string): string {
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return n
    .toString()
    .replace(/\d/g, (x) => farsiDigits[parseInt(x, 10)]);
}

/**
 * Format price in Tomans with comma separator and Persian digits
 */
export function formatTomans(amount: number): string {
  if (typeof amount !== 'number' || isNaN(amount)) return '۰';
  const formatted = amount.toLocaleString('en-US');
  return toPersianDigits(formatted);
}

/**
 * Format relative or standard Persian date
 */
export function formatPersianDate(dateString: string): string {
  try {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(date);
  } catch {
    return dateString;
  }
}
