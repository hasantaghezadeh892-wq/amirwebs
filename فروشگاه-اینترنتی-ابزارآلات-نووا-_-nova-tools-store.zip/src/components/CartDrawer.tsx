import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { formatTomans, toPersianDigits } from '../utils/formatters';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  ArrowLeft,
  CheckCircle2,
  Tag,
  CreditCard,
  MapPin,
  ShieldCheck,
  Truck
} from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    cartItems,
    isCartOpen,
    setIsCartOpen,
    updateQuantity,
    removeFromCart,
    subtotal,
    discountAmount,
    shippingCost,
    finalTotal,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    createOrder,
  } = useCart();

  const { user, openAuthModal } = useAuth();

  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState<string | null>(null);
  const [couponSuccess, setCouponSuccess] = useState<string | null>(null);

  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [shippingAddress, setShippingAddress] = useState('تهران، خیابان سهروردی شمالی، کوچه مریم، پلاک ۱۴');
  const [customerName, setCustomerName] = useState(user?.fullName || 'کاربر گرامی');
  const [customerEmail, setCustomerEmail] = useState(user?.email || 'customer@example.com');
  const [paymentMethod, setPaymentMethod] = useState<'درگاه آنلاین' | 'پرداخت در محل'>('درگاه آنلاین');
  const [orderSuccess, setOrderSuccess] = useState<string | null>(null);

  if (!isCartOpen) return null;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError(null);
    setCouponSuccess(null);
    if (!couponInput.trim()) return;

    const res = applyCoupon(couponInput);
    if (res.success) {
      setCouponSuccess(res.message);
      setCouponInput('');
    } else {
      setCouponError(res.message);
    }
  };

  const handleCompleteOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shippingAddress.trim() || !customerName.trim()) {
      alert('لطفاً آدرس و نام تحویل‌گیرنده را وارد کنید.');
      return;
    }

    const order = createOrder(shippingAddress, customerName, customerEmail, paymentMethod);
    setOrderSuccess(`سفارش شما با موفقیت با شماره پیگیری ${order.orderNumber} ثبت شد و در پنل مدیریت قابل پیگیری است.`);
    setIsCheckingOut(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs animate-in fade-in duration-200" dir="rtl">
      <div
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col border-r border-gray-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/70">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-red-600" />
            <h2 className="font-bold text-gray-800 text-sm">
              سبد خرید شما ({toPersianDigits(cartItems.length)} کالا)
            </h2>
          </div>
          <button
            onClick={() => {
              setIsCartOpen(false);
              setOrderSuccess(null);
              setIsCheckingOut(false);
            }}
            className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-200 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Order Success Notice */}
        {orderSuccess ? (
          <div className="flex-1 p-6 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-9 h-9" />
            </div>
            <h3 className="font-bold text-lg text-gray-900">سفارش شما با موفقیت ثبت گردید!</h3>
            <p className="text-xs text-gray-600 leading-relaxed max-w-xs">{orderSuccess}</p>
            <div className="p-3 bg-gray-50 rounded-xl text-xs text-gray-500 border border-gray-200">
              مدیر فروشگاه در پنل مدیریت وضعیت این سفارش را دریافت نموده و به زودی ارسال خواهد کرد.
            </div>
            <button
              onClick={() => {
                setIsCartOpen(false);
                setOrderSuccess(null);
              }}
              className="px-6 py-2.5 bg-red-600 text-white font-medium text-xs rounded-xl shadow-md hover:bg-red-700 transition-all"
            >
              ادامه خرید از نووا
            </button>
          </div>
        ) : cartItems.length === 0 ? (
          /* Empty State */
          <div className="flex-1 p-6 flex flex-col items-center justify-center text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-gray-100 text-gray-400 flex items-center justify-center">
              <ShoppingBag className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-gray-700 text-sm">سبد خرید شما خالی است</h3>
            <p className="text-xs text-gray-500 max-w-xs leading-relaxed">
              ابزارآلات حرفه‌ای نووا با تخفیف‌های شگفت‌انگیز را بررسی کرده و به سبد خریدتان بیفزایید.
            </p>
            <button
              onClick={() => setIsCartOpen(false)}
              className="mt-2 px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-semibold shadow-xs"
            >
              مشاهده محصولات نووا
            </button>
          </div>
        ) : isCheckingOut ? (
          /* Checkout Step */
          <form onSubmit={handleCompleteOrder} className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-gray-100">
              <span className="font-bold text-gray-800 text-sm">مشخصات تحویل و پرداخت</span>
              <button
                type="button"
                onClick={() => setIsCheckingOut(false)}
                className="text-red-600 text-xs flex items-center gap-1 font-medium hover:underline"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>بازگشت به سبد خرید</span>
              </button>
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-1">نام و نام خانوادگی تحویل‌گیرنده</label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-hidden focus:border-red-500 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-1">ایمیل یا شماره پیگیری</label>
              <input
                type="email"
                value={customerEmail}
                onChange={(e) => setCustomerEmail(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-hidden focus:border-red-500 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-1">آدرس کامل تحویل کالا</label>
              <textarea
                required
                rows={3}
                value={shippingAddress}
                onChange={(e) => setShippingAddress(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-hidden focus:border-red-500 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-2">روش پرداخت</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('درگاه آنلاین')}
                  className={`p-2.5 rounded-xl border text-right transition-all flex items-center gap-2 ${
                    paymentMethod === 'درگاه آنلاین'
                      ? 'border-red-600 bg-red-50/50 text-red-900 font-semibold'
                      : 'border-gray-200 text-gray-700'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-red-600 shrink-0" />
                  <span>درگاه امن آنلاین</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('پرداخت در محل')}
                  className={`p-2.5 rounded-xl border text-right transition-all flex items-center gap-2 ${
                    paymentMethod === 'پرداخت در محل'
                      ? 'border-red-600 bg-red-50/50 text-red-900 font-semibold'
                      : 'border-gray-200 text-gray-700'
                  }`}
                >
                  <Truck className="w-4 h-4 text-red-600 shrink-0" />
                  <span>پرداخت در محل</span>
                </button>
              </div>
            </div>

            {/* Price review */}
            <div className="bg-gray-50 rounded-xl p-3 space-y-1.5 border border-gray-100">
              <div className="flex justify-between text-gray-600">
                <span>جمع کل اقلام:</span>
                <span>{formatTomans(subtotal)} تومان</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-red-600 font-medium">
                  <span>تخفیف کوپن ({appliedCoupon?.percent}٪):</span>
                  <span>- {formatTomans(discountAmount)} تومان</span>
                </div>
              )}
              <div className="flex justify-between text-gray-600">
                <span>هزینه ارسال:</span>
                <span>{shippingCost === 0 ? 'رایگان' : `${formatTomans(shippingCost)} تومان`}</span>
              </div>
              <div className="pt-2 border-t border-gray-200 flex justify-between font-bold text-sm text-gray-900">
                <span>مبلغ نهایی پرداختی:</span>
                <span className="text-red-600">{formatTomans(finalTotal)} تومان</span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-xl text-xs shadow-md shadow-red-600/20 transition-all"
            >
              ثبت و پرداخت نهایی فاکتور ({formatTomans(finalTotal)} تومان)
            </button>
          </form>
        ) : (
          /* Normal Cart Items List */
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {cartItems.map((item) => (
                <div
                  key={item.product.id}
                  className="flex gap-3 p-3 bg-white border border-gray-100 rounded-xl shadow-xs hover:border-gray-200 transition-all"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.title}
                    className="w-18 h-18 object-cover rounded-lg border border-gray-100 shrink-0"
                  />
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <h4 className="font-semibold text-xs text-gray-800 line-clamp-2">
                        {item.product.title}
                      </h4>
                      <div className="text-[10px] text-gray-400 mt-0.5 flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-emerald-600" />
                        <span>{item.product.warranty}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg px-2 py-1">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                        <span className="text-xs font-bold font-mono px-1">
                          {toPersianDigits(item.quantity)}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          className="text-gray-500 hover:text-red-600"
                        >
                          {item.quantity === 1 ? (
                            <Trash2 className="w-3 h-3 text-red-500" />
                          ) : (
                            <Minus className="w-3 h-3" />
                          )}
                        </button>
                      </div>

                      <div className="text-left font-mono font-bold text-xs text-gray-900">
                        {formatTomans(item.product.price * item.quantity)}{' '}
                        <span className="text-[10px] font-normal text-gray-500">تومان</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {/* Coupon Box */}
              <div className="mt-4 p-3 bg-gray-50 border border-gray-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-gray-700 flex items-center gap-1.5">
                    <Tag className="w-3.5 h-3.5 text-red-500" />
                    <span>کد تخفیف نووا</span>
                  </span>
                  <span className="text-[10px] text-gray-400">کدهای معتبر: NOVA20 یا DIGINOVA</span>
                </div>

                {appliedCoupon ? (
                  <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-1.5 text-xs text-emerald-800">
                    <span className="font-semibold">
                      کد {appliedCoupon.code} فعال شد ({appliedCoupon.percent}٪ تخفیف)
                    </span>
                    <button
                      onClick={removeCoupon}
                      className="text-red-600 text-xs hover:underline"
                    >
                      حذف
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <input
                      type="text"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value)}
                      placeholder="کد تخفیف را وارد کنید..."
                      dir="ltr"
                      className="flex-1 bg-white border border-gray-200 rounded-lg px-3 py-1.5 text-xs font-mono uppercase focus:outline-hidden focus:border-red-500 text-right"
                    />
                    <button
                      type="submit"
                      className="px-3 py-1.5 bg-gray-800 hover:bg-gray-900 text-white rounded-lg text-xs font-medium transition-colors"
                    >
                      اعمال
                    </button>
                  </form>
                )}

                {couponError && <p className="text-[11px] text-red-600">{couponError}</p>}
                {couponSuccess && <p className="text-[11px] text-emerald-600">{couponSuccess}</p>}
              </div>
            </div>

            {/* Bottom Summary Bar */}
            <div className="p-4 border-t border-gray-100 bg-white space-y-2.5">
              <div className="flex justify-between text-xs text-gray-600">
                <span>جمع سبد خرید:</span>
                <span className="font-mono">{formatTomans(subtotal)} تومان</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-xs text-red-600 font-semibold">
                  <span>سود شما از خرید:</span>
                  <span className="font-mono">- {formatTomans(discountAmount)} تومان</span>
                </div>
              )}
              <div className="flex justify-between text-xs text-gray-600">
                <span>هزینه ارسال:</span>
                <span className="text-emerald-600 font-medium">
                  {shippingCost === 0 ? 'رایگان (سفارش بالای ۵۰۰ هزار تومان)' : `${formatTomans(shippingCost)} تومان`}
                </span>
              </div>
              <div className="flex justify-between font-bold text-sm text-gray-900 pt-1 border-t border-gray-100">
                <span>مبلغ قابل پرداخت:</span>
                <span className="text-red-600 font-mono text-base">{formatTomans(finalTotal)} تومان</span>
              </div>

              <button
                onClick={() => setIsCheckingOut(true)}
                className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-xl text-xs shadow-md shadow-red-600/20 transition-all active:scale-[0.99] flex items-center justify-center gap-2"
              >
                <span>تکمیل سفارش و ثبت آدرس</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
