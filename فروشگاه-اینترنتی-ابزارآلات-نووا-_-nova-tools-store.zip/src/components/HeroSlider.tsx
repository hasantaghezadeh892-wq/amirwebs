import React, { useState, useEffect } from 'react';
import { ChevronRight, ChevronLeft, ArrowLeft, ShieldCheck, Zap } from 'lucide-react';

interface Slide {
  id: string;
  badge: string;
  title: string;
  subtitle: string;
  ctaText: string;
  categoryFilter?: string;
  bgColor: string;
  accentColor: string;
  image: string;
}

const SLIDES: Slide[] = [
  {
    id: 'slide-1',
    badge: 'جشنواره ابزارآلات شارژی نووا',
    title: 'نسل جدید موتورهای براشلس صنعتی',
    subtitle: 'قدرت تخریب و سوراخکاری بدون افت توان با باتری‌های لیتیومی ۲۰ ولت سامسونگ و گارانتی طلایی تعویض',
    ctaText: 'مشاهده دریل‌های شارژی نووا',
    categoryFilter: 'ابزار برقی و شارژی',
    bgColor: 'from-slate-900 via-neutral-900 to-red-950',
    accentColor: 'text-red-500',
    image: 'https://images.unsplash.com/photo-1504148455328-c376907d081c?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'slide-2',
    badge: 'پیشنهاد ویژه کارگاهی',
    title: 'جعبه بکس‌های کروم وانادیوم نووا',
    subtitle: 'مجموعه‌های جامع ۹۴ و ۱۲۱ پارچه سخت‌کاری شده با گارانتی مادام‌العمر آلیاژ بدنه ضد سایش',
    ctaText: 'مشاهده ست‌های آچار و بکس',
    categoryFilter: 'ابزار دستی و عمومی',
    bgColor: 'from-zinc-950 via-slate-900 to-stone-900',
    accentColor: 'text-amber-500',
    image: 'https://images.unsplash.com/photo-1581244277943-fe4a9c777189?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'slide-3',
    badge: 'تکنولوژی جوشکاری مدرن',
    title: 'اینورترهای دیجیتال IGBT نووا',
    subtitle: 'پایداری فوق‌العاده قوس الکتریکی با مصرف کم برق و قابلیت ذوب مداوم الکترود ۴ برای پروژه‌های سنگین',
    ctaText: 'مشاهده دستگاه‌های جوش نووا',
    categoryFilter: 'تجهیزات جوش و برش',
    bgColor: 'from-neutral-950 via-slate-950 to-red-900',
    accentColor: 'text-red-400',
    image: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
  },
];

interface HeroSliderProps {
  onSelectCategory: (category: string | null) => void;
}

export const HeroSlider: React.FC<HeroSliderProps> = ({ onSelectCategory }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const slide = SLIDES[currentSlide];

  return (
    <div className="relative overflow-hidden rounded-2xl md:rounded-3xl shadow-xl border border-gray-100 max-w-7xl mx-auto my-4 sm:my-6">
      <div className={`relative min-h-[380px] sm:min-h-[440px] md:min-h-[480px] bg-gradient-to-r ${slide.bgColor} flex items-center transition-all duration-700`}>
        {/* Background Image with Overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src={slide.image}
            alt={slide.title}
            className="w-full h-full object-cover object-center mix-blend-overlay opacity-30 transform scale-105 transition-transform duration-1000"
          />
          <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-black/90 via-black/60 to-transparent"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-2xl px-6 sm:px-12 py-10 text-white space-y-4">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 text-white px-3.5 py-1.5 rounded-full text-xs font-semibold shadow-inner">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>{slide.badge}</span>
          </div>

          <h1 className="text-2xl sm:text-4xl md:text-5xl font-black tracking-tight leading-tight sm:leading-snug">
            {slide.title}
          </h1>

          <p className="text-xs sm:text-sm md:text-base text-gray-300 leading-relaxed max-w-xl font-normal">
            {slide.subtitle}
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onSelectCategory(slide.categoryFilter || null)}
              className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs sm:text-sm px-6 py-3 rounded-xl shadow-lg shadow-red-600/30 flex items-center gap-2 transition-all active:scale-[0.98]"
            >
              <span>{slide.ctaText}</span>
              <ArrowLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1.5 text-xs text-gray-300 bg-black/40 px-3 py-2.5 rounded-xl border border-white/10">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>گارانتی معتبر طلایی نووا</span>
            </div>
          </div>
        </div>

        {/* Slider Controls */}
        <div className="absolute bottom-5 left-6 sm:left-12 z-20 flex items-center gap-2">
          {SLIDES.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSlide(idx)}
              className={`h-2 rounded-full transition-all duration-300 ${
                currentSlide === idx ? 'w-8 bg-red-600' : 'w-2 bg-white/40 hover:bg-white/70'
              }`}
              title={`اسلاید ${idx + 1}`}
            />
          ))}
        </div>

        {/* Prev / Next Arrows */}
        <button
          onClick={() => setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length)}
          className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-20 p-2 sm:p-2.5 rounded-full bg-black/40 hover:bg-black/70 text-white border border-white/20 backdrop-blur-xs transition-all opacity-80 hover:opacity-100"
          title="قبلی"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
        <button
          onClick={() => setCurrentSlide((prev) => (prev + 1) % SLIDES.length)}
          className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-20 p-2 sm:p-2.5 rounded-full bg-black/40 hover:bg-black/70 text-white border border-white/20 backdrop-blur-xs transition-all opacity-80 hover:opacity-100"
          title="بعدی"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
