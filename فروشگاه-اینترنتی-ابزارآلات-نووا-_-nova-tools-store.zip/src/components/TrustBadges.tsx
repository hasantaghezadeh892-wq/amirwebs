import React from 'react';
import { Truck, Headphones, CreditCard, RotateCcw, ShieldCheck } from 'lucide-react';

export const TrustBadges: React.FC = () => {
  const BADGES = [
    {
      icon: Truck,
      title: 'امکان تحویل اکسپرس',
      desc: 'ارسال سریع به سراسر کشور',
      color: 'text-red-600',
      bgColor: 'bg-red-50',
    },
    {
      icon: Headphones,
      title: '۲۴ ساعته، ۷ روز هفته',
      desc: 'مشاوره تخصصی خرید ابزار',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      icon: CreditCard,
      title: 'امکان پرداخت در محل',
      desc: 'پرداخت امن اینترنتی یا حضوری',
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
    },
    {
      icon: RotateCcw,
      title: '۷ روز ضمانت بازگشت',
      desc: 'در صورت هرگونه مغایرت فنی',
      color: 'text-amber-600',
      bgColor: 'bg-amber-50',
    },
    {
      icon: ShieldCheck,
      title: 'ضمانت اصالت و گارانتی',
      desc: 'کالای ۱۰۰٪ اورجینال نووا',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
    },
  ];

  return (
    <div id="trust-badges" className="max-w-7xl mx-auto my-6 px-4">
      <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-xs grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        {BADGES.map((badge, idx) => {
          const Icon = badge.icon;
          return (
            <div
              key={idx}
              className="flex flex-col items-center text-center p-3 rounded-xl hover:bg-gray-50/80 transition-colors group"
            >
              <div
                className={`w-12 h-12 rounded-2xl ${badge.bgColor} ${badge.color} flex items-center justify-center mb-2.5 shadow-xs group-hover:scale-110 transition-transform`}
              >
                <Icon className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-xs sm:text-sm text-gray-800">{badge.title}</h4>
              <p className="text-[11px] text-gray-500 mt-1">{badge.desc}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
};
