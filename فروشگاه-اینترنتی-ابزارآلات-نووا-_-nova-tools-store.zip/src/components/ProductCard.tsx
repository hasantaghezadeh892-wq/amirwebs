import React, { useState } from 'react';
import { Product } from '../types';
import { formatTomans, toPersianDigits } from '../utils/formatters';
import { useCart } from '../context/CartContext';
import { Star, ShieldCheck, Plus, Check, Truck } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect }) => {
  const { addToCart } = useCart();
  const [isAdded, setIsAdded] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 1400);
  };

  return (
    <div
      onClick={() => onSelect(product)}
      className="bg-white rounded-2xl border border-gray-100 p-3.5 sm:p-4 hover:border-gray-200 hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer group relative"
      dir="rtl"
    >
      {/* Top Image area */}
      <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-gray-50 mb-3">
        <img
          src={product.image}
          alt={product.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        {/* Discount Badge */}
        {product.discountPercent > 0 && (
          <span className="absolute top-2.5 right-2.5 bg-red-600 text-white font-black text-xs px-2 py-0.5 rounded-full shadow-md font-mono">
            {toPersianDigits(product.discountPercent)}٪
          </span>
        )}

        {/* Special Offer Badge */}
        {product.isSpecialOffer && (
          <span className="absolute top-2.5 left-2.5 bg-amber-500 text-slate-950 font-bold text-[10px] px-2 py-0.5 rounded-md shadow-xs">
            شگفت‌انگیز
          </span>
        )}

        {/* Stock status indicator */}
        {!product.inStock && (
          <div className="absolute inset-0 bg-white/80 backdrop-blur-xs flex items-center justify-center">
            <span className="text-xs font-bold text-gray-600 bg-gray-100 px-3 py-1 rounded-full border border-gray-200">
              ناموجود
            </span>
          </div>
        )}
      </div>

      {/* Product Information */}
      <div className="space-y-1.5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-[11px] text-gray-400 mb-1">
            <span>{product.category}</span>
            <div className="flex items-center gap-1 text-amber-500 font-bold">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span>{toPersianDigits(product.rating)}</span>
              <span className="text-gray-400 font-normal">({toPersianDigits(product.reviewCount)})</span>
            </div>
          </div>

          <h3 className="font-bold text-xs sm:text-sm text-gray-800 line-clamp-2 leading-relaxed group-hover:text-red-600 transition-colors">
            {product.title}
          </h3>
        </div>

        {/* Delivery & Warranty info */}
        <div className="space-y-1 pt-1">
          <div className="flex items-center gap-1.5 text-[11px] text-gray-500">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span className="truncate">{product.warranty}</span>
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-gray-400">
            <Truck className="w-3.5 h-3.5 text-blue-500 shrink-0" />
            <span>ارسال اکسپرس نووا</span>
          </div>
        </div>

        {/* Price & Add to Cart */}
        <div className="pt-3 border-t border-gray-100 flex items-center justify-between mt-3">
          <div>
            {product.originalPrice > product.price && (
              <div className="text-[11px] text-gray-400 line-through font-mono">
                {formatTomans(product.originalPrice)}
              </div>
            )}
            <div className="font-black text-xs sm:text-sm text-gray-900 font-mono">
              {formatTomans(product.price)}{' '}
              <span className="text-[10px] sm:text-xs font-normal text-gray-500">تومان</span>
            </div>
          </div>

          <button
            onClick={handleAddToCart}
            disabled={!product.inStock}
            className={`p-2 sm:p-2.5 rounded-xl transition-all shadow-xs shrink-0 ${
              isAdded
                ? 'bg-emerald-600 text-white'
                : 'bg-red-600 hover:bg-red-700 text-white active:scale-95'
            } disabled:opacity-40 disabled:pointer-events-none`}
            title="افزودن به سبد خرید"
          >
            {isAdded ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};
