import React from 'react';
import { ArrowLeft, Sparkles, Shield, Wrench, Zap } from 'lucide-react';

interface BannerGridProps {
  onSelectCategory: (category: string) => void;
}

export const BannerGrid: React.FC<BannerGridProps> = ({ onSelectCategory }) => {
  return (
    <section className="max-w-7xl mx-auto my-8 px-4 space-y-6" dir="rtl">
      {/* 2-Banner Featured Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Banner 1: Power Tools */}
        <div
          onClick={() => onSelectCategory('ابزار برقی و شارژی')}
          className="relative h-48 sm:h-56 rounded-2xl md:rounded-3xl overflow-hidden cursor-pointer group shadow-sm hover:shadow-xl transition-all border border-gray-100"
        >
          <img
            src="https://images.unsplash.com/photo-1504148455328-c376907d081c?auto=format&fit=crop&w=1000&q=80"
            alt="دریل‌های شارژی صنعتی نووا"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-black/85 via-black/50 to-transparent"></div>
          <div className="absolute inset-0 p-6 flex flex-col justify-between text-white z-10">
            <div>
              <span className="text-[10px] sm:text-xs bg-red-600 text-white font-bold px-2.5 py-0.5 rounded-full inline-block mb-2">
                تکنولوژی براشلس ۲۰۲۶
              </span>
              <h3 className="text-lg sm:text-xl font-bold">دریل و پیچ‌گوشتی‌های شارژی نووا</h3>
              <p className="text-xs text-gray-300 mt-1 max-w-xs">
                دوام بی‌نظیر باتری و قدرت مضاعف برای کارهای سنگین کارگاهی
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold group-hover:gap-2.5 transition-all">
              <span>مشاهده و خرید آنلاین</span>
              <ArrowLeft className="w-4 h-4" />
            </div>
          </div>
        </div>

        {/* Banner 2: Hand Tools & Sets */}
        <div
          onClick={() => onSelectCategory('ابزار دستی و عمومی')}
          className="relative h-48 sm:h-56 rounded-2xl md:rounded-3xl overflow-hidden cursor-pointer group shadow-sm hover:shadow-xl transition-all border border-gray-100"
        >
          <img
            src="https://images.unsplash.com/photo-1581244277943-fe4a9c777189?auto=format&fit=crop&w=1000&q=80"
            alt="مجموعه آچار بکس نووا"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-slate-950/85 via-slate-900/50 to-transparent"></div>
          <div className="absolute inset-0 p-6 flex flex-col justify-between text-white z-10">
            <div>
              <span className="text-[10px] sm:text-xs bg-amber-500 text-slate-950 font-bold px-2.5 py-0.5 rounded-full inline-block mb-2">
                گارانتی مادام‌العمر آلیاژ
              </span>
              <h3 className="text-lg sm:text-xl font-bold">جعبه بکس‌های تمام فولادی کروم-وانادیوم</h3>
              <p className="text-xs text-gray-300 mt-1 max-w-xs">
                ست‌های ۹۴ و ۱۲۱ پارچه حرفه‌ای همراه کیف مستحکم BMC
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold group-hover:gap-2.5 transition-all">
              <span>مشاهده محصولات دستی</span>
              <ArrowLeft className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>

      {/* 4-Banner Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        {[
          {
            title: 'ابزار دقیق و لیزری',
            sub: 'متر و تراز لیزری ۳۶۰',
            category: 'ابزار اندازه‌گیری و دقیق',
            image: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=500&q=80',
            tag: 'دقت میلی‌متری',
          },
          {
            title: 'اینورترهای جوشکاری',
            sub: 'تکنولوژی IGBT توربو',
            category: 'تجهیزات جوش و برش',
            image: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=500&q=80',
            tag: '۲۰۰ تا ۲۵۰ آمپر',
          },
          {
            title: 'کمپرسورهای بادی سایلنت',
            sub: 'بدون روغن و بی‌صدا',
            category: 'ابزار بادی و بنزینی',
            image: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=500&q=80',
            tag: 'Oil-Free',
          },
          {
            title: 'کیف و جعبه ابزار',
            sub: 'فلزی و ارگانایزر',
            category: 'کیف و جعبه ابزار',
            image: 'https://images.unsplash.com/photo-1530124566582-a618bc2615dc?auto=format&fit=crop&w=500&q=80',
            tag: 'بدنه تقویت‌شده',
          },
        ].map((item, idx) => (
          <div
            key={idx}
            onClick={() => onSelectCategory(item.category)}
            className="relative h-32 sm:h-36 rounded-2xl overflow-hidden cursor-pointer group shadow-xs hover:shadow-md transition-all border border-gray-100"
          >
            <img
              src={item.image}
              alt={item.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent"></div>
            <div className="absolute inset-0 p-3.5 flex flex-col justify-between text-white z-10">
              <span className="text-[9px] bg-white/20 backdrop-blur-xs text-white px-2 py-0.5 rounded-md self-start">
                {item.tag}
              </span>
              <div>
                <h4 className="font-bold text-xs sm:text-sm text-white line-clamp-1">{item.title}</h4>
                <p className="text-[10px] text-gray-300 mt-0.5 line-clamp-1">{item.sub}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
