import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { formatTomans, toPersianDigits } from '../utils/formatters';
import { useCart } from '../context/CartContext';
import { Flame, Clock, Plus, ChevronLeft, Sparkles, Check } from 'lucide-react';

interface IncredibleOffersProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const IncredibleOffers: React.FC<IncredibleOffersProps> = ({
  products,
  onSelectProduct,
}) => {
  const { addToCart } = useCart();
  const [addedIds, setAddedIds] = useState<Record<string, boolean>>({});

  // Countdown timer state: 11 hours, 45 minutes, 30 seconds
  const [timeLeft, setTimeLeft] = useState({
    hours: 11,
    minutes: 42,
    seconds: 18,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return { hours: 12, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const specialOffers = products.filter((p) => p.isSpecialOffer);

  const handleAddToCart = (e: React.MouseEvent, product: Product) => {
    e.stopPropagation();
    addToCart(product, 1);
    setAddedIds((prev) => ({ ...prev, [product.id]: true }));
    setTimeout(() => {
      setAddedIds((prev) => ({ ...prev, [product.id]: false }));
    }, 1500);
  };

  return (
    <section id="incredible-offers" className="max-w-7xl mx-auto my-8 px-4" dir="rtl">
      <div className="bg-gradient-to-l from-red-600 via-rose-600 to-red-600 rounded-3xl p-5 sm:p-6 shadow-xl text-white">
        {/* Top bar inside the red section */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              <Flame className="w-7 h-7 text-amber-300 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
                <span>پیشنهاد شگفت‌انگیز نووا</span>
                <span className="text-[11px] bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full font-bold">
                  تخفیف ویژه روز
                </span>
              </h2>
              <p className="text-xs text-white/80 mt-0.5">
                تخفیف‌های محدود ابزارآلات حرفه‌ای نووا با ارسال فوری و گارانتی رسمی
              </p>
            </div>
          </div>

          {/* Countdown Clock */}
          <div className="flex items-center gap-2 bg-black/30 backdrop-blur-md border border-white/10 px-4 py-2 rounded-2xl shrink-0">
            <Clock className="w-4 h-4 text-amber-300" />
            <div className="flex items-center gap-1 font-mono text-sm font-bold" dir="ltr">
              <span className="bg-white/20 px-2 py-1 rounded-lg text-white">
                {toPersianDigits(timeLeft.hours.toString().padStart(2, '0'))}
              </span>
              <span className="text-amber-300">:</span>
              <span className="bg-white/20 px-2 py-1 rounded-lg text-white">
                {toPersianDigits(timeLeft.minutes.toString().padStart(2, '0'))}
              </span>
              <span className="text-amber-300">:</span>
              <span className="bg-white/20 px-2 py-1 rounded-lg text-white">
                {toPersianDigits(timeLeft.seconds.toString().padStart(2, '0'))}
              </span>
            </div>
          </div>
        </div>

        {/* Horizontal Scroll Product Cards */}
        <div className="flex items-stretch gap-4 overflow-x-auto pb-3 pt-1 scrollbar-none snap-x">
          {specialOffers.map((product) => (
            <div
              key={product.id}
              onClick={() => onSelectProduct(product)}
              className="w-64 sm:w-72 shrink-0 bg-white rounded-2xl p-4 text-gray-900 cursor-pointer shadow-md hover:shadow-2xl transition-all duration-300 flex flex-col justify-between group snap-start border border-transparent hover:border-red-200"
            >
              {/* Product Image & Badges */}
              <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-gray-50 mb-3">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {product.discountPercent > 0 && (
                  <span className="absolute top-2.5 right-2.5 bg-red-600 text-white font-black text-xs px-2.5 py-1 rounded-full shadow-md font-mono">
                    {toPersianDigits(product.discountPercent)}٪
                  </span>
                )}
                <span className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-xs text-white text-[10px] px-2 py-0.5 rounded-md">
                  شگفت‌انگیز
                </span>
              </div>

              {/* Title & Brand */}
              <div className="space-y-1.5 flex-1">
                <div className="text-[10px] font-semibold text-gray-400">
                  {product.category}
                </div>
                <h3 className="font-bold text-xs sm:text-sm text-gray-800 line-clamp-2 leading-snug group-hover:text-red-600 transition-colors">
                  {product.title}
                </h3>
              </div>

              {/* Stock Warning Bar */}
              <div className="my-2.5">
                <div className="flex justify-between text-[10px] text-gray-500 mb-1">
                  <span>موجودی در انبار:</span>
                  <span className="text-red-600 font-semibold">
                    تنها {toPersianDigits(product.stockCount)} عدد باقیست
                  </span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-red-500 h-1.5 rounded-full"
                    style={{ width: `${Math.min(100, (product.stockCount / 20) * 100)}%` }}
                  ></div>
                </div>
              </div>

              {/* Price & Add to Cart Row */}
              <div className="pt-2 border-t border-gray-100 flex items-center justify-between mt-auto">
                <div>
                  {product.originalPrice > product.price && (
                    <div className="text-[11px] text-gray-400 line-through font-mono">
                      {formatTomans(product.originalPrice)}
                    </div>
                  )}
                  <div className="font-black text-sm text-gray-900 font-mono">
                    {formatTomans(product.price)}{' '}
                    <span className="text-[11px] font-normal text-gray-600">تومان</span>
                  </div>
                </div>

                <button
                  onClick={(e) => handleAddToCart(e, product)}
                  className={`p-2.5 rounded-xl transition-all shadow-xs ${
                    addedIds[product.id]
                      ? 'bg-emerald-600 text-white'
                      : 'bg-red-600 hover:bg-red-700 text-white'
                  }`}
                  title="افزودن به سبد خرید"
                >
                  {addedIds[product.id] ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <Plus className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
