import React, { useState, useMemo } from 'react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';
import { toPersianDigits } from '../utils/formatters';
import { Filter, ArrowUpDown, SlidersHorizontal, Sparkles } from 'lucide-react';

interface ProductGridProps {
  products: Product[];
  selectedCategory: string | null;
  onSelectCategory: (category: string | null) => void;
  onSelectProduct: (product: Product) => void;
}

type SortType = 'popular' | 'bestseller' | 'cheapest' | 'expensive' | 'discount';

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  selectedCategory,
  onSelectCategory,
  onSelectProduct,
}) => {
  const [sortType, setSortType] = useState<SortType>('popular');
  const [inStockOnly, setInStockOnly] = useState(false);

  const categories = [
    'همه محصولات',
    'ابزار برقی و شارژی',
    'ابزار دستی و عمومی',
    'ابزار بادی و بنزینی',
    'ابزار اندازه‌گیری و دقیق',
    'تجهیزات جوش و برش',
    'کیف و جعبه ابزار',
  ];

  const filteredAndSortedProducts = useMemo(() => {
    let result = [...products];

    // Filter by Category
    if (selectedCategory && selectedCategory !== 'همه محصولات') {
      result = result.filter((p) => p.category === selectedCategory);
    }

    // Filter in-stock only
    if (inStockOnly) {
      result = result.filter((p) => p.inStock);
    }

    // Sort
    switch (sortType) {
      case 'bestseller':
        result.sort((a, b) => (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0));
        break;
      case 'cheapest':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'expensive':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'discount':
        result.sort((a, b) => b.discountPercent - a.discountPercent);
        break;
      case 'popular':
      default:
        result.sort((a, b) => b.rating - a.rating);
        break;
    }

    return result;
  }, [products, selectedCategory, sortType, inStockOnly]);

  return (
    <section id="products-catalog" className="max-w-7xl mx-auto my-8 px-4" dir="rtl">
      {/* Category Pills Slider */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none mb-4">
        {categories.map((cat) => {
          const isSelected =
            (cat === 'همه محصولات' && !selectedCategory) ||
            selectedCategory === cat;

          return (
            <button
              key={cat}
              onClick={() => onSelectCategory(cat === 'همه محصولات' ? null : cat)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/20'
                  : 'bg-white text-gray-700 border border-gray-200 hover:border-gray-300 hover:bg-gray-50'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Sorting and Filter Bar */}
      <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-xs mb-6 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none text-xs">
          <div className="flex items-center gap-1.5 text-gray-500 font-medium shrink-0 ml-2">
            <ArrowUpDown className="w-4 h-4 text-red-600" />
            <span>مرتب‌سازی بر اساس:</span>
          </div>

          <button
            onClick={() => setSortType('popular')}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              sortType === 'popular'
                ? 'bg-red-50 text-red-600 font-bold'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            محبوب‌ترین
          </button>
          <button
            onClick={() => setSortType('bestseller')}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              sortType === 'bestseller'
                ? 'bg-red-50 text-red-600 font-bold'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            پرفروش‌ترین
          </button>
          <button
            onClick={() => setSortType('cheapest')}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              sortType === 'cheapest'
                ? 'bg-red-50 text-red-600 font-bold'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            ارزان‌ترین
          </button>
          <button
            onClick={() => setSortType('expensive')}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              sortType === 'expensive'
                ? 'bg-red-50 text-red-600 font-bold'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            گران‌ترین
          </button>
          <button
            onClick={() => setSortType('discount')}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              sortType === 'discount'
                ? 'bg-red-50 text-red-600 font-bold'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            بیشترین تخفیف
          </button>
        </div>

        {/* Right side: In-stock toggle and count */}
        <div className="flex items-center justify-between md:justify-end gap-4 shrink-0 text-xs border-t md:border-t-0 pt-3 md:pt-0 border-gray-100">
          <label className="flex items-center gap-2 cursor-pointer text-gray-700 select-none">
            <input
              type="checkbox"
              checked={inStockOnly}
              onChange={(e) => setInStockOnly(e.target.checked)}
              className="w-4 h-4 rounded text-red-600 border-gray-300 focus:ring-red-500"
            />
            <span>فقط کالاهای موجود</span>
          </label>

          <span className="text-gray-400 font-medium font-mono">
            {toPersianDigits(filteredAndSortedProducts.length)} کالا
          </span>
        </div>
      </div>

      {/* Grid of Product Cards */}
      {filteredAndSortedProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
          {filteredAndSortedProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={onSelectProduct}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-2xl p-12 text-center text-gray-500 space-y-3">
          <p className="text-sm">کالایی در این دسته‌بندی یافت نشد.</p>
          <button
            onClick={() => onSelectCategory(null)}
            className="px-4 py-2 bg-red-600 text-white rounded-xl text-xs font-semibold"
          >
            مشاهده تمام ابزارها
          </button>
        </div>
      )}
    </section>
  );
};
