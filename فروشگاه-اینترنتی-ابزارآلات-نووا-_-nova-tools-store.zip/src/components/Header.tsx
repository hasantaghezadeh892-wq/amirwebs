import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { Product } from '../types';
import { formatTomans, toPersianDigits } from '../utils/formatters';
import {
  Search,
  ShoppingCart,
  User as UserIcon,
  MapPin,
  ShieldAlert,
  ChevronDown,
  Sparkles,
  Flame,
  Award,
  Layers,
  Wrench,
  Zap,
  PhoneCall,
  LogOut,
  LayoutDashboard,
  ShieldCheck,
  Check
} from 'lucide-react';

interface HeaderProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  selectedCategory: string | null;
  onSelectCategory: (category: string | null) => void;
}

const CITIES = ['تهران', 'اصفهان', 'مشهد', 'شیراز', 'تبریز', 'کرج', 'اهواز', 'قم'];

export const Header: React.FC<HeaderProps> = ({
  products,
  onSelectProduct,
  selectedCategory,
  onSelectCategory,
}) => {
  const { user, isAdmin, openAuthModal, logout, setCurrentView } = useAuth();
  const { totalItems, setIsCartOpen } = useCart();

  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isCityMenuOpen, setIsCityMenuOpen] = useState(false);
  const [selectedCity, setSelectedCity] = useState('تهران');
  const [isCategoriesMenuOpen, setIsCategoriesMenuOpen] = useState(false);

  const searchRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const cityMenuRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setIsSearchFocused(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setIsUserMenuOpen(false);
      }
      if (cityMenuRef.current && !cityMenuRef.current.contains(e.target as Node)) {
        setIsCityMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const searchResults = searchQuery.trim()
    ? products
        .filter(
          (p) =>
            p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
            (p.englishTitle && p.englishTitle.toLowerCase().includes(searchQuery.toLowerCase()))
        )
        .slice(0, 6)
    : [];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-gray-200 shadow-xs" dir="rtl">
      {/* Top Banner Notice */}
      <div className="bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white text-xs py-2 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
            <span className="bg-white/20 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0">
              جشنواره نووا
            </span>
            <span className="font-medium text-[11px] sm:text-xs">
              تخفیف‌های شگفت‌انگیز تا ۵۰٪ روی ابزارآلات برقی، شارژی و بکس‌های نووا با گارانتی طلایی
            </span>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {isAdmin ? (
              <button
                onClick={() => setCurrentView('admin')}
                className="bg-white text-red-700 hover:bg-red-50 text-[11px] font-bold px-2.5 py-0.5 rounded-md transition-colors shadow-xs flex items-center gap-1"
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                <span>ورود به پنل مدیریت</span>
              </button>
            ) : (
              <button
                onClick={() => openAuthModal('login')}
                className="text-[11px] text-white/90 hover:text-white underline underline-offset-4 decoration-white/40"
              >
                ورود مدیر سیستم (admin / 88142)
              </button>
            )}
            <div className="hidden md:flex items-center gap-1 text-[11px] text-white/90">
              <PhoneCall className="w-3 h-3" />
              <span dir="ltr">021-66750000</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header Row */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-3.5">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <div
            onClick={() => {
              onSelectCategory(null);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-2.5 cursor-pointer shrink-0 select-none group"
          >
            <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center text-white font-black text-xl tracking-wider shadow-md shadow-red-600/30 group-hover:scale-105 transition-transform">
              N
            </div>
            <div className="flex flex-col">
              <span className="font-black text-xl tracking-tight text-gray-900 group-hover:text-red-600 transition-colors">
                نووا <span className="text-red-600 text-sm font-bold font-mono">NOVA</span>
              </span>
              <span className="text-[10px] text-gray-500 font-medium -mt-1 tracking-wider">
                ابزارآلات صنعتی و حرفه‌ای
              </span>
            </div>
          </div>

          {/* Search Box */}
          <div ref={searchRef} className="flex-1 max-w-2xl relative hidden sm:block">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                placeholder="جستجو در تمام ابزارآلات نووا (دریل، فرز، اینورتر، بکس، متر لیزری...)"
                className="w-full bg-gray-100/90 border border-transparent hover:border-gray-300 focus:border-red-500 focus:bg-white rounded-xl py-2.5 pr-10 pl-4 text-xs md:text-sm text-gray-800 placeholder-gray-400 focus:outline-hidden transition-all shadow-inner-xs"
              />
              <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-3" />
            </div>

            {/* Instant Search Results Dropdown */}
            {isSearchFocused && searchQuery.trim() && (
              <div className="absolute top-full mt-1.5 left-0 right-0 bg-white border border-gray-200 rounded-xl shadow-xl overflow-hidden z-50">
                {searchResults.length > 0 ? (
                  <div className="divide-y divide-gray-100">
                    <div className="p-2.5 bg-gray-50 text-[11px] font-semibold text-gray-500">
                      نتایج جستجو برای «{searchQuery}» ({toPersianDigits(searchResults.length)} کالا)
                    </div>
                    {searchResults.map((product) => (
                      <div
                        key={product.id}
                        onClick={() => {
                          onSelectProduct(product);
                          setIsSearchFocused(false);
                          setSearchQuery('');
                        }}
                        className="p-3 hover:bg-gray-50 cursor-pointer flex items-center gap-3 transition-colors"
                      >
                        <img
                          src={product.image}
                          alt={product.title}
                          className="w-12 h-12 object-cover rounded-lg border border-gray-100 shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-gray-800 line-clamp-1">
                            {product.title}
                          </p>
                          <span className="text-[10px] text-gray-400">
                            دسته‌بندی: {product.category}
                          </span>
                        </div>
                        <div className="text-left font-mono font-bold text-xs text-red-600 shrink-0">
                          {formatTomans(product.price)} <span className="text-[10px] text-gray-500">تومان</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 text-center text-xs text-gray-500">
                    کالایی با عبارت «{searchQuery}» یافت نشد. لطفاً عنوان دیگری را جستجو کنید.
                  </div>
                )}
              </div>
            )}
          </div>

          {/* User Account & Cart Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* User Dropdown / Auth Button */}
            {user ? (
              <div ref={userMenuRef} className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
                    isAdmin
                      ? 'bg-red-50 border-red-300 text-red-700 hover:bg-red-100'
                      : 'bg-gray-50 border-gray-200 text-gray-800 hover:bg-gray-100'
                  }`}
                >
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold ${
                    isAdmin ? 'bg-red-600' : 'bg-gray-800'
                  }`}>
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                  <span className="max-w-[100px] truncate">{user.fullName || user.username}</span>
                  {isAdmin && (
                    <span className="bg-red-600 text-white text-[9px] px-1.5 py-0.2 rounded font-bold">
                      ادمین
                    </span>
                  )}
                  <ChevronDown className="w-3.5 h-3.5 text-gray-500" />
                </button>

                {isUserMenuOpen && (
                  <div className="absolute left-0 mt-1.5 w-56 bg-white border border-gray-200 rounded-xl shadow-xl py-1.5 z-50 text-xs">
                    <div className="px-4 py-2 border-b border-gray-100">
                      <p className="font-bold text-gray-800">{user.fullName || user.username}</p>
                      <p className="text-[10px] text-gray-400 font-mono mt-0.5">
                        {user.email || `@${user.username}`}
                      </p>
                      <span className="inline-block mt-1 text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded">
                        ورود با: {user.authProvider === 'google' ? 'حساب گوگل' : 'نام کاربری و رمز'}
                      </span>
                    </div>

                    {isAdmin && (
                      <button
                        onClick={() => {
                          setCurrentView('admin');
                          setIsUserMenuOpen(false);
                        }}
                        className="w-full px-4 py-2 text-right text-red-600 hover:bg-red-50 font-bold flex items-center gap-2 transition-colors"
                      >
                        <LayoutDashboard className="w-4 h-4 text-red-600" />
                        <span>ورود به پنل مدیریت</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        alert('بخش تاریخچه سفارش‌ها در سبد خرید و پنل مدیریت در دسترس است.');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full px-4 py-2 text-right text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                    >
                      <Award className="w-4 h-4 text-gray-400" />
                      <span>باشگاه مشتریان و گارانتی نووا</span>
                    </button>

                    <div className="border-t border-gray-100 my-1"></div>

                    <button
                      onClick={() => {
                        logout();
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full px-4 py-2 text-right text-red-600 hover:bg-red-50 flex items-center gap-2 font-medium"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>خروج از حساب</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => openAuthModal('login')}
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-gray-800 border border-gray-300 hover:border-gray-400 hover:bg-gray-50 transition-all shadow-2xs"
              >
                <UserIcon className="w-4 h-4 text-gray-600" />
                <span>ورود / ثبت‌نام</span>
              </button>
            )}

            <div className="w-px h-6 bg-gray-200"></div>

            {/* Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2.5 rounded-xl hover:bg-gray-100 text-gray-800 transition-colors"
              title="سبد خرید"
            >
              <ShoppingCart className="w-5 h-5 text-gray-700" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-600 text-white font-mono font-bold text-[10px] w-5 h-5 rounded-full flex items-center justify-center shadow-xs">
                  {toPersianDigits(totalItems)}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="mt-2.5 sm:hidden relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="جستجو در ابزارآلات نووا..."
            className="w-full bg-gray-100 border border-transparent rounded-xl py-2 pr-9 pl-3 text-xs text-gray-800 placeholder-gray-400"
          />
          <Search className="w-3.5 h-3.5 text-gray-400 absolute right-3 top-2.5" />
        </div>
      </div>

      {/* Sub-header Navigation */}
      <div className="border-t border-gray-100 bg-gray-50/50">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between text-xs font-medium text-gray-600 overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1 sm:gap-2 py-2 shrink-0">
            {/* Categories button */}
            <div className="relative">
              <button
                onClick={() => setIsCategoriesMenuOpen(!isCategoriesMenuOpen)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors font-bold ${
                  selectedCategory
                    ? 'text-red-600 bg-red-50'
                    : 'text-gray-900 hover:text-red-600 hover:bg-gray-100'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-red-600" />
                <span>دسته‌بندی کالاها</span>
                <ChevronDown className="w-3 h-3 text-gray-400" />
              </button>

              {isCategoriesMenuOpen && (
                <div
                  className="absolute top-full mt-1 right-0 w-56 bg-white border border-gray-200 rounded-xl shadow-xl py-2 z-50 text-xs"
                  onClick={() => setIsCategoriesMenuOpen(false)}
                >
                  <button
                    onClick={() => onSelectCategory(null)}
                    className="w-full px-4 py-2 text-right hover:bg-gray-50 font-bold text-gray-900 flex items-center justify-between"
                  >
                    <span>همه محصولات نووا</span>
                    {!selectedCategory && <Check className="w-3.5 h-3.5 text-red-600" />}
                  </button>
                  <div className="border-t border-gray-100 my-1"></div>
                  {[
                    'ابزار برقی و شارژی',
                    'ابزار دستی و عمومی',
                    'ابزار بادی و بنزینی',
                    'ابزار اندازه‌گیری و دقیق',
                    'تجهیزات جوش و برش',
                    'کیف و جعبه ابزار',
                  ].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => onSelectCategory(cat)}
                      className={`w-full px-4 py-2 text-right hover:bg-gray-50 flex items-center justify-between ${
                        selectedCategory === cat ? 'text-red-600 font-bold' : 'text-gray-700'
                      }`}
                    >
                      <span>{cat}</span>
                      {selectedCategory === cat && <Check className="w-3.5 h-3.5 text-red-600" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={() => {
                onSelectCategory(null);
                const elem = document.getElementById('incredible-offers');
                elem?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="flex items-center gap-1 px-2.5 py-1.5 hover:text-red-600 transition-colors"
            >
              <Flame className="w-3.5 h-3.5 text-red-600" />
              <span className="font-bold text-red-600">شگفت‌انگیزها</span>
            </button>

            <button
              onClick={() => onSelectCategory('ابزار برقی و شارژی')}
              className={`flex items-center gap-1 px-2.5 py-1.5 hover:text-red-600 transition-colors ${
                selectedCategory === 'ابزار برقی و شارژی' ? 'text-red-600 font-bold' : ''
              }`}
            >
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              <span>دریل و شارژی</span>
            </button>

            <button
              onClick={() => onSelectCategory('ابزار دستی و عمومی')}
              className={`flex items-center gap-1 px-2.5 py-1.5 hover:text-red-600 transition-colors ${
                selectedCategory === 'ابزار دستی و عمومی' ? 'text-red-600 font-bold' : ''
              }`}
            >
              <Wrench className="w-3.5 h-3.5 text-blue-500" />
              <span>ابزار دستی و بکس</span>
            </button>

            <button
              onClick={() => {
                const elem = document.getElementById('trust-badges');
                elem?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="hidden lg:flex items-center gap-1 px-2.5 py-1.5 hover:text-red-600 transition-colors"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>گارانتی و اصالت کالا</span>
            </button>
          </div>

          {/* City Delivery Selector */}
          <div ref={cityMenuRef} className="relative shrink-0 py-2">
            <button
              onClick={() => setIsCityMenuOpen(!isCityMenuOpen)}
              className="flex items-center gap-1.5 text-gray-600 hover:text-gray-900 px-2 py-1 rounded-lg hover:bg-gray-100 transition-colors text-[11px]"
            >
              <MapPin className="w-3.5 h-3.5 text-red-600" />
              <span>ارسال به: <strong className="text-gray-800">{selectedCity}</strong></span>
              <ChevronDown className="w-3 h-3 text-gray-400" />
            </button>

            {isCityMenuOpen && (
              <div className="absolute top-full mt-1 left-0 w-40 bg-white border border-gray-200 rounded-xl shadow-lg py-1.5 z-50 text-xs">
                <div className="px-3 py-1 text-[10px] font-semibold text-gray-400 border-b border-gray-100">
                  انتخاب استان و شهر
                </div>
                {CITIES.map((city) => (
                  <button
                    key={city}
                    onClick={() => {
                      setSelectedCity(city);
                      setIsCityMenuOpen(false);
                    }}
                    className={`w-full px-3 py-1.5 text-right hover:bg-gray-50 flex items-center justify-between ${
                      selectedCity === city ? 'text-red-600 font-bold' : 'text-gray-700'
                    }`}
                  >
                    <span>{city}</span>
                    {selectedCity === city && <Check className="w-3 h-3 text-red-600" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
