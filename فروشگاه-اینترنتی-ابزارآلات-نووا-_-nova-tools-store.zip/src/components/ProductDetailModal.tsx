import React, { useState } from 'react';
import { Product } from '../types';
import { formatTomans, toPersianDigits } from '../utils/formatters';
import { useCart } from '../context/CartContext';
import {
  X,
  Star,
  ShieldCheck,
  Truck,
  CheckCircle2,
  Plus,
  Minus,
  Check,
  Share2,
  Clock
} from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
}) => {
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [isAdded, setIsAdded] = useState(false);

  if (!product) return null;

  const handleAdd = () => {
    addToCart(product, quantity);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 1500);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      dir="rtl"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col border border-gray-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-gray-50/70">
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <span>ابزارآلات نووا</span>
            <span>/</span>
            <span className="text-gray-800 font-medium">{product.category}</span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-200 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Image Area */}
            <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-gray-50 border border-gray-100">
              <img
                src={product.image}
                alt={product.title}
                className="w-full h-full object-cover"
              />
              {product.discountPercent > 0 && (
                <span className="absolute top-3 right-3 bg-red-600 text-white font-black text-sm px-3 py-1 rounded-full shadow-md font-mono">
                  {toPersianDigits(product.discountPercent)}٪ تخفیف
                </span>
              )}
            </div>

            {/* Product Meta */}
            <div className="flex flex-col justify-between space-y-4">
              <div>
                <span className="text-xs font-semibold text-red-600 bg-red-50 px-2.5 py-1 rounded-lg">
                  {product.brand} • ضمانت کیفیت صنعتی
                </span>

                <h2 className="text-lg sm:text-xl font-bold text-gray-900 mt-2 leading-relaxed">
                  {product.title}
                </h2>

                {product.englishTitle && (
                  <p className="text-xs text-gray-400 font-mono mt-0.5" dir="ltr">
                    {product.englishTitle}
                  </p>
                )}

                <div className="flex items-center gap-2 mt-2 text-xs">
                  <div className="flex items-center gap-1 text-amber-500 font-bold">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span>{toPersianDigits(product.rating)}</span>
                  </div>
                  <span className="text-gray-400">•</span>
                  <span className="text-gray-500">
                    {toPersianDigits(product.reviewCount)} دیدگاه خریداران
                  </span>
                </div>
              </div>

              {/* Guarantees Box */}
              <div className="bg-gray-50 rounded-2xl p-3.5 space-y-2 border border-gray-100 text-xs">
                <div className="flex items-center gap-2 text-gray-700">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="font-medium">{product.warranty}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700">
                  <Truck className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>ارسال سریع اکسپرس به سراسر کشور</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700">
                  <Clock className="w-4 h-4 text-purple-600 shrink-0" />
                  <span>۷ روز ضمانت بازگشت و تعویض نووا</span>
                </div>
              </div>

              {/* Price & Quantity & Add to Cart */}
              <div className="pt-3 border-t border-gray-100 space-y-3">
                <div className="flex items-baseline justify-between">
                  <span className="text-xs text-gray-500">قیمت مصرف‌کننده:</span>
                  <div className="text-left">
                    {product.originalPrice > product.price && (
                      <div className="text-xs text-gray-400 line-through font-mono">
                        {formatTomans(product.originalPrice)} تومان
                      </div>
                    )}
                    <div className="text-xl font-black text-gray-900 font-mono">
                      {formatTomans(product.price)}{' '}
                      <span className="text-xs font-normal text-gray-500">تومان</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-3 bg-gray-100 rounded-xl px-3 py-2 border border-gray-200">
                    <button
                      onClick={() => setQuantity((q) => q + 1)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                    <span className="font-mono font-bold text-sm w-4 text-center">
                      {toPersianDigits(quantity)}
                    </span>
                    <button
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      className="text-gray-600 hover:text-red-600"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                  </div>

                  <button
                    onClick={handleAdd}
                    className={`flex-1 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.99] ${
                      isAdded
                        ? 'bg-emerald-600 text-white shadow-emerald-600/30'
                        : 'bg-red-600 hover:bg-red-700 text-white shadow-red-600/30'
                    }`}
                  >
                    {isAdded ? (
                      <>
                        <Check className="w-4 h-4" />
                        <span>به سبد خرید اضافه شد</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4" />
                        <span>افزودن به سبد خرید</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Features Checklist */}
          {product.features && product.features.length > 0 && (
            <div className="border-t border-gray-100 pt-5">
              <h4 className="font-bold text-sm text-gray-900 mb-3">ویژگی‌های برجسته محصول</h4>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-700">
                {product.features.map((feat, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Technical Specs Table */}
          {product.specs && (
            <div className="border-t border-gray-100 pt-5">
              <h4 className="font-bold text-sm text-gray-900 mb-3">مشخصات فنی تخصصی</h4>
              <div className="bg-gray-50 rounded-2xl overflow-hidden border border-gray-100 text-xs divide-y divide-gray-200/60">
                {Object.entries(product.specs).map(([key, val], idx) => (
                  <div key={idx} className="grid grid-cols-3 p-3">
                    <span className="text-gray-500 font-medium">{key}</span>
                    <span className="col-span-2 text-gray-800 font-semibold">{val}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
