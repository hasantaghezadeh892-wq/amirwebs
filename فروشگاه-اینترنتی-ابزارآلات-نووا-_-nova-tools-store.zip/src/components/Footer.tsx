import React from 'react';
import { ArrowUp, Phone, Mail, MapPin, ShieldCheck, Award, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-white border-t border-gray-200 mt-16 pt-8 pb-12 text-gray-600 text-xs" dir="rtl">
      <div className="max-w-7xl mx-auto px-4">
        {/* Back to Top bar */}
        <div className="flex items-center justify-between pb-6 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-red-600 flex items-center justify-center font-black text-white text-base">
              N
            </div>
            <div>
              <span className="font-bold text-gray-900 text-sm">
                فروشگاه اینترنتی ابزارآلات نووا | NOVA TOOLS
              </span>
              <p className="text-[11px] text-gray-400">
                مرجع تخصصی خرید آنلاین ابزارآلات صنعتی، برقی، شارژی و بکس‌های کارگاهی
              </p>
            </div>
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 px-4 py-2 border border-gray-200 hover:border-gray-300 rounded-xl font-medium text-gray-700 hover:bg-gray-50 transition-colors shadow-2xs"
          >
            <span>بازگشت به بالا</span>
            <ArrowUp className="w-3.5 h-3.5 text-gray-500" />
          </button>
        </div>

        {/* Contact info bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-6 border-b border-gray-100 text-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center shrink-0">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <span className="text-gray-400 block text-[10px]">تلفن پشتیبانی ۲۴ ساعته:</span>
              <span className="font-bold text-gray-800 font-mono" dir="ltr">021-66750000</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <span className="text-gray-400 block text-[10px]">ایمیل خدمات پس از فروش:</span>
              <span className="font-medium text-gray-800 font-mono">support@novatools.ir</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <span className="text-gray-400 block text-[10px]">دفتر مرکزی نووا:</span>
              <span className="font-medium text-gray-800">تهران، میدان حسن‌آباد، خیابان امام خمینی</span>
            </div>
          </div>
        </div>

        {/* Links Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-8 border-b border-gray-100">
          <div>
            <h4 className="font-bold text-gray-900 text-xs sm:text-sm mb-3">ابزارآلات برقی و شارژی</h4>
            <ul className="space-y-2 text-[11px] text-gray-500">
              <li className="hover:text-red-600 cursor-pointer">دریل‌های چکشی و گیربکسی</li>
              <li className="hover:text-red-600 cursor-pointer">فرز و مینی‌فرز دیمردار</li>
              <li className="hover:text-red-600 cursor-pointer">بتن‌کن‌های ۴ شیار و ۵ شیار</li>
              <li className="hover:text-red-600 cursor-pointer">پیچ‌گوشتی‌های شارژی لیتیومی</li>
              <li className="hover:text-red-600 cursor-pointer">اره‌های فارسی‌بر و دیسکی</li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-gray-900 text-xs sm:text-sm mb-3">ابزار دستی و کارگاهی</h4>
            <ul className="space-y-2 text-[11px] text-gray-500">
              <li className="hover:text-red-600 cursor-pointer">جعبه بکس‌های کروم وانادیوم</li>
              <li className="hover:text-red-600 cursor-pointer">ست‌های انبرآلات صنعتی</li>
              <li className="hover:text-red-600 cursor-pointer">آچارهای یکسر رینگ و جغجغه‌ای</li>
              <li className="hover:text-red-600 cursor-pointer">جعبه ابزارهای فلزی سه طبقه</li>
              <li className="hover:text-red-600 cursor-pointer">مترهای نواری و لیزری ۱۰۰ متری</li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-gray-900 text-xs sm:text-sm mb-3">خدمات مشتریان نووا</h4>
            <ul className="space-y-2 text-[11px] text-gray-500">
              <li className="hover:text-red-600 cursor-pointer">پاسخ به پرسش‌های متداول</li>
              <li className="hover:text-red-600 cursor-pointer">رویه‌های بازگرداندن کالا</li>
              <li className="hover:text-red-600 cursor-pointer">شرایط گارانتی طلایی تعویض</li>
              <li className="hover:text-red-600 cursor-pointer">حریم خصوصی و قوانین خرید</li>
              <li className="hover:text-red-600 cursor-pointer">گزارش تخلف یا اصالت‌سنجی</li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-gray-900 text-xs sm:text-sm mb-3">ضمانت‌ها و نمادهای اعتماد</h4>
            <div className="grid grid-cols-3 gap-2">
              <div className="p-3 bg-gray-50 border border-gray-200 rounded-xl flex flex-col items-center justify-center text-center">
                <ShieldCheck className="w-6 h-6 text-emerald-600 mb-1" />
                <span className="text-[9px] text-gray-600 font-bold">ضمانت اصالت</span>
              </div>
              <div className="p-3 bg-gray-50 border border-gray-200 rounded-xl flex flex-col items-center justify-center text-center">
                <Award className="w-6 h-6 text-amber-500 mb-1" />
                <span className="text-[9px] text-gray-600 font-bold">ایران کد</span>
              </div>
              <div className="p-3 bg-gray-50 border border-gray-200 rounded-xl flex flex-col items-center justify-center text-center">
                <ShieldCheck className="w-6 h-6 text-blue-600 mb-1" />
                <span className="text-[9px] text-gray-600 font-bold">اینماد ۵ ستاره</span>
              </div>
            </div>
            <p className="text-[10px] text-gray-400 mt-3 leading-relaxed">
              کلیه حقوق این سامانه متعلق به فروشگاه رسمی ابزارآلات نووا (Nova Tools) می‌باشد.
            </p>
          </div>
        </div>

        {/* Bottom Copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-gray-400 gap-2">
          <p>
            طراحی و پیاده‌سازی طبق استانداردهای پیشرفته فروشگاهی دیجی‌کالا و برند صنعتی نووا
          </p>
          <p className="flex items-center gap-1 font-mono">
            <span>© 2026 Nova Tools Inc. All rights reserved.</span>
          </p>
        </div>
      </div>
    </footer>
  );
};
