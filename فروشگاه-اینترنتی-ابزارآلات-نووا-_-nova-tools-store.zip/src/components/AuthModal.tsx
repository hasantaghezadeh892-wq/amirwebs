import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { X, Lock, User as UserIcon, Eye, EyeOff, ShieldCheck, CheckCircle2, AlertCircle } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authModalTab,
    loginWithCredentials,
    signupWithCredentials,
    loginWithGoogle,
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'login' | 'signup'>(authModalTab);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Sync tab with context when opening
  React.useEffect(() => {
    setActiveTab(authModalTab);
    setError(null);
    setSuccessMsg(null);
  }, [authModalTab, isAuthModalOpen]);

  if (!isAuthModalOpen) return null;

  const handleFillAdmin = () => {
    setActiveTab('login');
    setUsername('admin');
    setPassword('88142');
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (activeTab === 'login') {
        if (!username.trim() || !password) {
          setError('لطفاً نام کاربری و رمز عبور را وارد کنید.');
          setLoading(false);
          return;
        }

        const res = await loginWithCredentials(username, password);
        if (!res.success) {
          setError(res.message || 'خطا در ورود به حساب کاربری.');
        } else {
          setSuccessMsg(res.message || 'ورود موفقیت‌آمیز بود.');
        }
      } else {
        // Sign-up
        if (!username.trim()) {
          setError('لطفاً نام کاربری را وارد کنید.');
          setLoading(false);
          return;
        }
        if (password.length < 4) {
          setError('رمز عبور باید حداقل ۴ کاراکتر باشد.');
          setLoading(false);
          return;
        }
        if (password !== confirmPassword) {
          setError('رمز عبور و تکرار آن یکسان نیستند.');
          setLoading(false);
          return;
        }

        const res = await signupWithCredentials(username, password, fullName);
        if (!res.success) {
          setError(res.message || 'خطا در ثبت‌نام.');
        } else {
          setSuccessMsg(res.message || 'ثبت‌نام با موفقیت انجام شد.');
        }
      }
    } catch {
      setError('خطای غیرمنتظره رخ داد. دوباره تلاش کنید.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await loginWithGoogle();
      if (!res.success) {
        setError(res.message || 'خطا در اتصال به حساب گوگل');
      }
    } catch {
      setError('خطا در ورود با گوگل');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with Close */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-gray-50/70">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-white font-bold text-sm tracking-wider">
              NOVA
            </div>
            <span className="font-semibold text-gray-800 text-sm">
              {activeTab === 'login' ? 'ورود به حساب کاربری' : 'ثبت‌نام در فروشگاه نووا'}
            </span>
          </div>
          <button
            onClick={closeAuthModal}
            className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-200/60 rounded-full transition-colors"
            title="بستن"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Admin Quick Login Badge Prompt */}
        <div className="mx-6 mt-4 p-3 bg-red-50 border border-red-200 rounded-xl flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs text-red-800 font-medium">
              <ShieldCheck className="w-4 h-4 text-red-600 shrink-0" />
              <span>ورود مستقیم مدیر به پنل مدیریت:</span>
            </div>
            <button
              type="button"
              onClick={handleFillAdmin}
              className="text-xs bg-red-600 hover:bg-red-700 text-white px-2.5 py-1 rounded-lg font-medium transition-colors shadow-xs"
            >
              تکمیل ادمین (admin / 88142)
            </button>
          </div>
          <div className="text-[11px] text-red-700/80 flex items-center gap-3">
            <span>نام کاربری: <code className="bg-white/80 px-1 py-0.5 rounded font-mono font-bold text-red-900">admin</code></span>
            <span>رمز عبور: <code className="bg-white/80 px-1 py-0.5 rounded font-mono font-bold text-red-900">88142</code></span>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-gray-200 px-6 mt-3">
          <button
            type="button"
            onClick={() => {
              setActiveTab('login');
              setError(null);
            }}
            className={`flex-1 py-2.5 text-sm font-semibold transition-all relative ${
              activeTab === 'login'
                ? 'text-red-600 border-b-2 border-red-600'
                : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            ورود
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('signup');
              setError(null);
            }}
            className={`flex-1 py-2.5 text-sm font-semibold transition-all relative ${
              activeTab === 'signup'
                ? 'text-red-600 border-b-2 border-red-600'
                : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            ثبت‌نام جدید
          </button>
        </div>

        <div className="p-6">
          {/* Notice: No Mobile Phone Number constraint enforced */}
          {activeTab === 'signup' && (
            <div className="mb-4 text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg p-2.5 flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                ثبت‌نام بدون نیاز به شماره موبایل! ثبت‌نام فقط از طریق <strong>حساب گوگل</strong> یا <strong>نام کاربری و رمز عبور</strong> انجام می‌شود.
              </span>
            </div>
          )}

          {/* Google Auth Button */}
          <button
            type="button"
            onClick={handleGoogleAuth}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 py-2.5 px-4 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-xl font-medium text-sm shadow-xs transition-all mb-4 hover:border-gray-400 active:scale-[0.99]"
          >
            <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>
              {activeTab === 'login' ? 'ورود با حساب گوگل' : 'ثبت‌نام مستقیم با حساب گوگل'}
            </span>
          </button>

          <div className="relative flex items-center justify-center my-4">
            <div className="border-t border-gray-200 w-full"></div>
            <span className="bg-white px-3 text-xs text-gray-400 absolute">
              یا از طریق نام کاربری و رمز عبور
            </span>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-700 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {activeTab === 'signup' && (
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  نام و نام خانوادگی (اختیاری)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="مثال: محمد امینی"
                    className="w-full pl-3 pr-10 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-hidden focus:border-red-500 focus:bg-white transition-colors"
                  />
                  <UserIcon className="w-4 h-4 text-gray-400 absolute right-3 top-3" />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">
                نام کاربری <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="مثال: admin یا نام کاربری دلخواه"
                  dir="ltr"
                  className="w-full pl-3 pr-10 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-mono focus:outline-hidden focus:border-red-500 focus:bg-white transition-colors text-right"
                  required
                />
                <UserIcon className="w-4 h-4 text-gray-400 absolute right-3 top-3" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">
                رمز عبور <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="رمز عبور"
                  dir="ltr"
                  className="w-full pl-10 pr-10 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-mono focus:outline-hidden focus:border-red-500 focus:bg-white transition-colors"
                  required
                />
                <Lock className="w-4 h-4 text-gray-400 absolute right-3 top-3" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-3 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {activeTab === 'signup' && (
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  تکرار رمز عبور <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="تکرار همان رمز عبور"
                    dir="ltr"
                    className="w-full pl-10 pr-10 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-mono focus:outline-hidden focus:border-red-500 focus:bg-white transition-colors"
                    required
                  />
                  <Lock className="w-4 h-4 text-gray-400 absolute right-3 top-3" />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-xl text-sm shadow-md shadow-red-600/20 hover:shadow-lg transition-all active:scale-[0.99] disabled:opacity-50"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                  <span>در حال پردازش...</span>
                </span>
              ) : activeTab === 'login' ? (
                'ورود به حساب کاربری'
              ) : (
                'تکمیل و ثبت‌نام در نووا'
              )}
            </button>
          </form>

          {/* Footer note */}
          <div className="mt-4 pt-3 border-t border-gray-100 text-center">
            {activeTab === 'login' ? (
              <p className="text-xs text-gray-500">
                حساب کاربری ندارید؟{' '}
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('signup');
                    setError(null);
                  }}
                  className="text-red-600 hover:underline font-semibold"
                >
                  هم‌اکنون ثبت‌نام کنید
                </button>
              </p>
            ) : (
              <p className="text-xs text-gray-500">
                قبلاً ثبت‌نام کرده‌اید؟{' '}
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('login');
                    setError(null);
                  }}
                  className="text-red-600 hover:underline font-semibold"
                >
                  وارد شوید
                </button>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
