import React from 'react';
import { Category } from '../types';
import { toPersianDigits } from '../utils/formatters';
import { Zap, Wrench, Wind, Ruler, Flame, Box, ChevronLeft } from 'lucide-react';

interface CategoriesGridProps {
  categories: Category[];
  selectedCategory: string | null;
  onSelectCategory: (categoryName: string | null) => void;
}

const ICON_MAP: Record<string, React.ElementType> = {
  Zap,
  Wrench,
  Wind,
  Ruler,
  Flame,
  Box,
};

export const CategoriesGrid: React.FC<CategoriesGridProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
}) => {
  return (
    <section className="max-w-7xl mx-auto my-8 px-4" dir="rtl">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-gray-900">
            دسته‌بندی‌های تخصصی ابزارآلات نووا
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            تجهیزات صنعتی و کارگاهی مطابق با نیازهای استادکاران و صنعتگران
          </p>
        </div>

        {selectedCategory && (
          <button
            onClick={() => onSelectCategory(null)}
            className="text-xs text-red-600 font-bold hover:underline flex items-center gap-1"
          >
            <span>نمایش همه دسته‌ها</span>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5 sm:gap-4">
        {categories.map((cat) => {
          const Icon = ICON_MAP[cat.iconName] || Wrench;
          const isSelected = selectedCategory === cat.name;

          return (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(isSelected ? null : cat.name)}
              className={`p-4 rounded-2xl cursor-pointer transition-all duration-300 flex flex-col items-center text-center border group ${
                isSelected
                  ? 'bg-red-50/70 border-red-500 shadow-md ring-2 ring-red-500/20'
                  : 'bg-white border-gray-100 hover:border-gray-200 hover:shadow-lg shadow-xs'
              }`}
            >
              <div className="relative w-16 h-16 rounded-2xl overflow-hidden bg-gray-50 mb-3 border border-gray-100 group-hover:scale-105 transition-transform duration-300">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/10"></div>
                <div className="absolute inset-0 flex items-center justify-center text-white drop-shadow-md">
                  <Icon className="w-7 h-7" />
                </div>
              </div>

              <h3 className={`font-bold text-xs sm:text-sm transition-colors ${
                isSelected ? 'text-red-600' : 'text-gray-800 group-hover:text-red-600'
              }`}>
                {cat.name}
              </h3>
              <span className="text-[10px] text-gray-400 mt-1">
                {toPersianDigits(cat.count)}+ مدل کالا
              </span>
            </div>
          );
        })}
      </div>
    </section>
  );
};
