import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { Product, Order } from '../types';
import { formatTomans, toPersianDigits, formatPersianDate } from '../utils/formatters';
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Users,
  Settings,
  ArrowRight,
  Plus,
  Trash2,
  Edit3,
  Search,
  CheckCircle,
  Clock,
  Truck,
  XCircle,
  TrendingUp,
  Tag,
  DollarSign,
  AlertTriangle,
  LogOut,
  Save,
  ShieldCheck,
  X
} from 'lucide-react';

interface AdminPanelProps {
  products: Product[];
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  products,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
}) => {
  const { user, setCurrentView, logout, allUsers } = useAuth();
  const { orders, updateOrderStatus } = useCart();

  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'users' | 'settings'>('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // New product form state
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState('ابزار برقی و شارژی');
  const [newPrice, setNewPrice] = useState('');
  const [newOriginalPrice, setNewOriginalPrice] = useState('');
  const [newStock, setNewStock] = useState('10');
  const [newImage, setNewImage] = useState('');
  const [newWarranty, setNewWarranty] = useState('گارانتی ۱۲ ماهه طلایی نووا');
  const [newIsSpecial, setNewIsSpecial] = useState(false);

  // Calculation for stats
  const totalRevenue = orders.reduce((acc, o) => acc + o.finalAmount, 0);
  const pendingOrders = orders.filter((o) => o.status === 'در حال پردازش').length;
  const lowStockProducts = products.filter((p) => p.stockCount <= 5);

  const filteredProducts = products.filter(
    (p) =>
      p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = parseInt(newPrice.replace(/[^0-9]/g, ''), 10) || 0;
    const origPriceNum = parseInt(newOriginalPrice.replace(/[^0-9]/g, ''), 10) || priceNum;
    const discount = origPriceNum > priceNum ? Math.round(((origPriceNum - priceNum) / origPriceNum) * 100) : 0;

    const prod: Product = {
      id: 'nova-custom-' + Date.now(),
      title: newTitle.trim(),
      category: newCategory,
      categoryId: newCategory === 'ابزار برقی و شارژی' ? 'cordless-power' : 'hand-tools',
      price: priceNum,
      originalPrice: origPriceNum,
      discountPercent: discount,
      rating: 5.0,
      reviewCount: 1,
      image: newImage.trim() || 'https://images.unsplash.com/photo-1504148455328-c376907d081c?auto=format&fit=crop&w=800&q=80',
      inStock: parseInt(newStock, 10) > 0,
      stockCount: parseInt(newStock, 10) || 0,
      isSpecialOffer: newIsSpecial,
      isBestSeller: false,
      brand: 'Nova',
      warranty: newWarranty,
      features: ['تولید شده با استانداردهای بین‌المللی نووا', 'کیفیت ساخت صنعتی'],
      specs: { 'اصالت کالا': 'اورجینال نووا', 'گارانتی': newWarranty },
    };

    onAddProduct(prod);
    setIsAddModalOpen(false);
    // Reset
    setNewTitle('');
    setNewPrice('');
    setNewOriginalPrice('');
    setNewImage('');
  };

  const handleSaveEditProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    onUpdateProduct(editingProduct);
    setEditingProduct(null);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans" dir="rtl">
      {/* Top Admin Navbar */}
      <header className="bg-slate-800 border-b border-slate-700 px-6 py-3.5 flex items-center justify-between sticky top-0 z-40 shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-red-600 flex items-center justify-center font-black text-white text-base tracking-wider shadow-md shadow-red-600/30">
            NOVA
          </div>
          <div>
            <h1 className="font-bold text-base text-white flex items-center gap-2">
              پنل مدیریت هوشمند ابزارآلات نووا
              <span className="text-[11px] bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded-full font-medium">
                نسخه مدیریت ارشد
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              کاربر متصل: <strong className="text-slate-200">{user?.fullName || user?.username} ({user?.username})</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentView('store')}
            className="flex items-center gap-2 bg-slate-700 hover:bg-slate-600 text-slate-200 hover:text-white px-3.5 py-2 rounded-xl text-xs font-semibold transition-all border border-slate-600 shadow-xs"
          >
            <ArrowRight className="w-4 h-4" />
            <span>مشاهده فروشگاه (سایت)</span>
          </button>
          <button
            onClick={logout}
            className="flex items-center gap-1.5 bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white px-3 py-2 rounded-xl text-xs font-medium transition-all border border-red-500/30"
            title="خروج از حساب"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">خروج</span>
          </button>
        </div>
      </header>

      {/* Main Layout: Sidebar + Content */}
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Sidebar */}
        <aside className="w-full md:w-64 bg-slate-800/60 border-l border-slate-700 p-4 shrink-0">
          <nav className="space-y-1.5">
            <button
              onClick={() => setActiveTab('overview')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                activeTab === 'overview'
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/60'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 shrink-0" />
              <span>داشبورد و آمار کلی</span>
            </button>

            <button
              onClick={() => setActiveTab('products')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                activeTab === 'products'
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <Package className="w-4 h-4 shrink-0" />
                <span>مدیریت محصولات</span>
              </div>
              <span className="text-xs bg-slate-700 text-slate-300 px-2 py-0.5 rounded-full">
                {toPersianDigits(products.length)}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('orders')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                activeTab === 'orders'
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <ShoppingCart className="w-4 h-4 shrink-0" />
                <span>سفارش‌ها</span>
              </div>
              {pendingOrders > 0 && (
                <span className="text-xs bg-amber-500 text-slate-950 font-bold px-2 py-0.5 rounded-full">
                  {toPersianDigits(pendingOrders)} جدید
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('users')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                activeTab === 'users'
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <Users className="w-4 h-4 shrink-0" />
                <span>کاربران و ثبت‌نام‌ها</span>
              </div>
              <span className="text-xs bg-slate-700 text-slate-300 px-2 py-0.5 rounded-full">
                {toPersianDigits(allUsers.length)}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                activeTab === 'settings'
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/60'
              }`}
            >
              <Settings className="w-4 h-4 shrink-0" />
              <span>تنظیمات فروشگاه</span>
            </button>
          </nav>

          <div className="mt-8 p-3.5 rounded-xl bg-slate-800/90 border border-slate-700/80 text-xs text-slate-400 space-y-2">
            <div className="font-semibold text-slate-200 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>دسترسی مدیریت تأیید شده</span>
            </div>
            <p className="leading-relaxed text-[11px]">
              ورود با شناسه <code className="text-red-400 font-mono font-bold">admin</code> معتبر شناخته شده و دسترسی کامل به پایگاه کالاها و سفارش‌ها فعال است.
            </p>
          </div>
        </aside>

        {/* Content Body */}
        <main className="flex-1 p-6 overflow-y-auto">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Stat Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5 shadow-sm">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-medium">فروش و درآمد کل</span>
                    <DollarSign className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div className="text-2xl font-bold text-white tracking-tight">
                    {formatTomans(totalRevenue)} <span className="text-xs font-normal text-slate-400">تومان</span>
                  </div>
                  <p className="text-[11px] text-emerald-400 mt-2 flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>رشد ۱۸٪ نسبت به هفته گذشته</span>
                  </p>
                </div>

                <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5 shadow-sm">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-medium">کل سفارش‌های ثبت‌شده</span>
                    <ShoppingCart className="w-5 h-5 text-blue-400" />
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {toPersianDigits(orders.length)}{' '}
                    <span className="text-xs font-normal text-slate-400">سفارش</span>
                  </div>
                  <p className="text-[11px] text-amber-400 mt-2 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{toPersianDigits(pendingOrders)} سفارش در انتظار ارسال</span>
                  </p>
                </div>

                <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5 shadow-sm">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-medium">کاربران ثبت‌نامی</span>
                    <Users className="w-5 h-5 text-purple-400" />
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {toPersianDigits(allUsers.length)}{' '}
                    <span className="text-xs font-normal text-slate-400">کاربر</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-2">
                    شامل ورودهای حساب گوگل و نام کاربری
                  </p>
                </div>

                <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5 shadow-sm">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-medium">محصولات موجود در انبار</span>
                    <Package className="w-5 h-5 text-red-400" />
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {toPersianDigits(products.length)}{' '}
                    <span className="text-xs font-normal text-slate-400">مدل کالا</span>
                  </div>
                  {lowStockProducts.length > 0 ? (
                    <p className="text-[11px] text-amber-400 mt-2 flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>{toPersianDigits(lowStockProducts.length)} کالا رو به اتمام است</span>
                    </p>
                  ) : (
                    <p className="text-[11px] text-emerald-400 mt-2">موجودی انبار در وضعیت پایدار</p>
                  )}
                </div>
              </div>

              {/* Recent Orders Overview */}
              <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-bold text-base text-white flex items-center gap-2">
                    <ShoppingCart className="w-4 h-4 text-red-500" />
                    <span>آخرین سفارش‌های ثبت‌شده مشتریان</span>
                  </h2>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className="text-xs text-red-400 hover:text-red-300 font-medium"
                  >
                    مشاهده همه سفارش‌ها
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-right text-xs">
                    <thead>
                      <tr className="border-b border-slate-700 text-slate-400 pb-2">
                        <th className="py-2.5 px-3">کد سفارش</th>
                        <th className="py-2.5 px-3">خریدار</th>
                        <th className="py-2.5 px-3">تعداد اقلام</th>
                        <th className="py-2.5 px-3">مبلغ پرداختی</th>
                        <th className="py-2.5 px-3">تاریخ</th>
                        <th className="py-2.5 px-3">وضعیت</th>
                        <th className="py-2.5 px-3 text-center">عملیات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700/60">
                      {orders.slice(0, 5).map((ord) => (
                        <tr key={ord.id} className="hover:bg-slate-700/30 transition-colors">
                          <td className="py-3 px-3 font-mono font-bold text-red-400">
                            {ord.orderNumber}
                          </td>
                          <td className="py-3 px-3 text-slate-200">
                            <div>{ord.customerName}</div>
                            <div className="text-[10px] text-slate-500">{ord.customerEmail}</div>
                          </td>
                          <td className="py-3 px-3 text-slate-300">
                            {toPersianDigits(ord.items.reduce((s, i) => s + i.quantity, 0))} کالا
                          </td>
                          <td className="py-3 px-3 font-semibold text-emerald-400">
                            {formatTomans(ord.finalAmount)} تومان
                          </td>
                          <td className="py-3 px-3 text-slate-400 text-[11px]">
                            {formatPersianDate(ord.date)}
                          </td>
                          <td className="py-3 px-3">
                            <span
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-semibold ${
                                ord.status === 'تحویل شده'
                                  ? 'bg-emerald-500/20 text-emerald-300'
                                  : ord.status === 'ارسال شده'
                                  ? 'bg-blue-500/20 text-blue-300'
                                  : ord.status === 'لغو شده'
                                  ? 'bg-red-500/20 text-red-300'
                                  : 'bg-amber-500/20 text-amber-300'
                              }`}
                            >
                              {ord.status}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-center">
                            <select
                              value={ord.status}
                              onChange={(e) => updateOrderStatus(ord.id, e.target.value as Order['status'])}
                              className="bg-slate-700 border border-slate-600 rounded-lg px-2 py-1 text-[11px] text-slate-200 focus:outline-hidden focus:border-red-500"
                            >
                              <option value="در حال پردازش">در حال پردازش</option>
                              <option value="ارسال شده">ارسال شده</option>
                              <option value="تحویل شده">تحویل شده</option>
                              <option value="لغو شده">لغو شده</option>
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PRODUCTS MANAGEMENT */}
          {activeTab === 'products' && (
            <div className="space-y-5">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md">
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="جستجو در نام محصول یا دسته..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pr-10 pl-4 py-2.5 text-xs text-slate-100 placeholder-slate-400 focus:outline-hidden focus:border-red-500"
                  />
                  <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
                </div>

                <button
                  onClick={() => setIsAddModalOpen(true)}
                  className="bg-red-600 hover:bg-red-700 text-white px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-md shadow-red-600/30 transition-all active:scale-[0.98]"
                >
                  <Plus className="w-4 h-4" />
                  <span>افزودن محصول جدید نووا</span>
                </button>
              </div>

              {/* Products Table */}
              <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-right text-xs">
                    <thead>
                      <tr className="bg-slate-800/80 border-b border-slate-700 text-slate-400 font-medium">
                        <th className="py-3 px-4">تصویر</th>
                        <th className="py-3 px-4">نام کالا</th>
                        <th className="py-3 px-4">دسته‌بندی</th>
                        <th className="py-3 px-4">قیمت فروش (تومان)</th>
                        <th className="py-3 px-4">تخفیف</th>
                        <th className="py-3 px-4">موجودی</th>
                        <th className="py-3 px-4">شگفت‌انگیز</th>
                        <th className="py-3 px-4 text-center">عملیات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700/60">
                      {filteredProducts.map((prod) => (
                        <tr key={prod.id} className="hover:bg-slate-750 transition-colors">
                          <td className="py-2.5 px-4">
                            <img
                              src={prod.image}
                              alt={prod.title}
                              className="w-12 h-12 object-cover rounded-lg border border-slate-600 bg-white"
                            />
                          </td>
                          <td className="py-2.5 px-4 font-medium text-slate-200 max-w-xs">
                            <div className="line-clamp-2">{prod.title}</div>
                            <div className="text-[10px] text-slate-500">{prod.brand} • {prod.warranty}</div>
                          </td>
                          <td className="py-2.5 px-4 text-slate-400">
                            {prod.category}
                          </td>
                          <td className="py-2.5 px-4 font-semibold text-emerald-400 font-mono">
                            {formatTomans(prod.price)}
                          </td>
                          <td className="py-2.5 px-4">
                            {prod.discountPercent > 0 ? (
                              <span className="bg-red-500/20 text-red-400 font-bold px-2 py-0.5 rounded-full text-[10px]">
                                {toPersianDigits(prod.discountPercent)}٪
                              </span>
                            ) : (
                              <span className="text-slate-500">-</span>
                            )}
                          </td>
                          <td className="py-2.5 px-4">
                            <span
                              className={`px-2 py-0.5 rounded-md text-[10px] font-semibold ${
                                prod.stockCount > 5
                                  ? 'bg-slate-700 text-slate-200'
                                  : prod.stockCount > 0
                                  ? 'bg-amber-500/20 text-amber-400'
                                  : 'bg-red-500/20 text-red-400'
                              }`}
                            >
                              {toPersianDigits(prod.stockCount)} عدد
                            </span>
                          </td>
                          <td className="py-2.5 px-4">
                            <button
                              onClick={() =>
                                onUpdateProduct({ ...prod, isSpecialOffer: !prod.isSpecialOffer })
                              }
                              className={`px-2 py-1 rounded-lg text-[10px] font-medium transition-colors ${
                                prod.isSpecialOffer
                                  ? 'bg-red-600 text-white shadow-xs'
                                  : 'bg-slate-700 text-slate-400 hover:text-slate-200'
                              }`}
                            >
                              {prod.isSpecialOffer ? 'شگفت‌انگیز فعال' : 'عادی'}
                            </button>
                          </td>
                          <td className="py-2.5 px-4 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => setEditingProduct(prod)}
                                className="p-1.5 text-blue-400 hover:bg-blue-500/10 rounded-lg transition-colors"
                                title="ویرایش کالا"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm(`آیا از حذف "${prod.title}" اطمینان دارید؟`)) {
                                    onDeleteProduct(prod.id);
                                  }
                                }}
                                className="p-1.5 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                                title="حذف کالا"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: ORDERS MANAGEMENT */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-bold text-base text-white">مدیریت سفارش‌های مشتریان</h2>
                <span className="text-xs text-slate-400">
                  مجموع: {toPersianDigits(orders.length)} سفارش
                </span>
              </div>

              <div className="space-y-3">
                {orders.map((ord) => (
                  <div
                    key={ord.id}
                    className="bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-4 hover:border-slate-600 transition-all shadow-xs"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-700/80 pb-3">
                      <div className="flex items-center gap-3">
                        <span className="font-mono font-bold text-red-400 text-sm">
                          {ord.orderNumber}
                        </span>
                        <span className="text-xs text-slate-400">
                          {formatPersianDate(ord.date)}
                        </span>
                        <span className="text-xs bg-slate-700 px-2.5 py-0.5 rounded-full text-slate-300">
                          روش: {ord.paymentMethod}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-400">وضعیت سفارش:</span>
                        <select
                          value={ord.status}
                          onChange={(e) => updateOrderStatus(ord.id, e.target.value as Order['status'])}
                          className="bg-slate-700 border border-slate-600 rounded-lg px-2.5 py-1 text-xs text-white font-medium focus:outline-hidden focus:border-red-500"
                        >
                          <option value="در حال پردازش">در حال پردازش</option>
                          <option value="ارسال شده">ارسال شده</option>
                          <option value="تحویل شده">تحویل شده</option>
                          <option value="لغو شده">لغو شده</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                      <div>
                        <span className="text-slate-400 block mb-1">مشخصات خریدار:</span>
                        <p className="font-medium text-slate-200">{ord.customerName}</p>
                        <p className="text-slate-400">{ord.customerEmail}</p>
                      </div>

                      <div>
                        <span className="text-slate-400 block mb-1">آدرس ارسال مرسوله:</span>
                        <p className="text-slate-200 leading-relaxed">{ord.shippingAddress}</p>
                      </div>

                      <div className="md:text-left">
                        <span className="text-slate-400 block mb-1">مبلغ پرداختی فاکتور:</span>
                        <p className="text-base font-bold text-emerald-400 font-mono">
                          {formatTomans(ord.finalAmount)} تومان
                        </p>
                      </div>
                    </div>

                    {/* Ordered Items Preview */}
                    <div className="bg-slate-900/60 rounded-xl p-3 flex flex-wrap gap-3">
                      {ord.items.map((item, idx) => (
                        <div key={idx} className="flex items-center gap-2 bg-slate-800 p-2 rounded-lg border border-slate-700/60 text-xs">
                          <img
                            src={item.product.image}
                            alt={item.product.title}
                            className="w-8 h-8 rounded-md object-cover bg-white shrink-0"
                          />
                          <div>
                            <p className="font-medium text-slate-200 line-clamp-1 max-w-[200px]">
                              {item.product.title}
                            </p>
                            <span className="text-slate-400 text-[11px]">
                              {toPersianDigits(item.quantity)} عدد × {formatTomans(item.product.price)} تومان
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: USERS MANAGEMENT */}
          {activeTab === 'users' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-bold text-base text-white">کاربران ثبت‌نام شده</h2>
                  <p className="text-xs text-slate-400">
                    ثبت‌نام‌ها منحصراً از طریق حساب گوگل یا نام کاربری و رمز عبور صورت گرفته‌اند (شماره موبایل حذف گردیده است).
                  </p>
                </div>
                <span className="text-xs bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-xl font-medium text-slate-300">
                  تعداد کل: {toPersianDigits(allUsers.length)} کاربر
                </span>
              </div>

              <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden shadow-xs">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="bg-slate-800/80 border-b border-slate-700 text-slate-400 font-medium">
                      <th className="py-3 px-4">نام و نام خانوادگی</th>
                      <th className="py-3 px-4">نام کاربری</th>
                      <th className="py-3 px-4">ایمیل</th>
                      <th className="py-3 px-4">روش ثبت‌نام</th>
                      <th className="py-3 px-4">سطح دسترسی</th>
                      <th className="py-3 px-4">تاریخ عضویت</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {allUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-750 transition-colors">
                        <td className="py-3 px-4 font-medium text-slate-200">
                          {u.fullName || u.username}
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-red-400">
                          {u.username}
                        </td>
                        <td className="py-3 px-4 text-slate-400">
                          {u.email || '-'}
                        </td>
                        <td className="py-3 px-4">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-medium ${
                            u.authProvider === 'google'
                              ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                              : 'bg-slate-700 text-slate-300'
                          }`}>
                            {u.authProvider === 'google' ? 'حساب گوگل (Google)' : 'نام کاربری و رمز'}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                              u.role === 'admin'
                                ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                                : 'bg-slate-700 text-slate-300'
                            }`}
                          >
                            {u.role === 'admin' ? 'مدیر کل (Admin)' : 'کاربر عادی'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-400 text-[11px]">
                          {formatPersianDate(u.createdAt)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 5: STORE SETTINGS */}
          {activeTab === 'settings' && (
            <div className="max-w-2xl bg-slate-800 border border-slate-700 rounded-2xl p-6 space-y-6">
              <h2 className="font-bold text-base text-white pb-3 border-b border-slate-700">
                تنظیمات فروشگاه و برند نووا
              </h2>

              <div className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-300 font-medium mb-1.5">
                    نام برند و فروشگاه
                  </label>
                  <input
                    type="text"
                    defaultValue="فروشگاه تخصصی ابزارآلات نووا (Nova Tools)"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-hidden focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1.5">
                    متن بنر اعلان بالای سایت
                  </label>
                  <input
                    type="text"
                    defaultValue="جشنواره شگفت‌انگیز ابزارآلات نووا | تا ۵۰٪ تخفیف و ارسال رایگان سراسر کشور"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-hidden focus:border-red-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 font-medium mb-1.5">
                      تلفن امور مشتریان
                    </label>
                    <input
                      type="text"
                      dir="ltr"
                      defaultValue="021-66750000"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-slate-100 font-mono focus:outline-hidden focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-medium mb-1.5">
                      کد تخفیف پیش‌فرض فعال
                    </label>
                    <input
                      type="text"
                      dir="ltr"
                      defaultValue="NOVA20 (۲۰٪ تخفیف)"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-slate-100 font-mono focus:outline-hidden focus:border-red-500"
                    />
                  </div>
                </div>

                <div className="pt-3">
                  <button
                    type="button"
                    onClick={() => alert('تنظیمات با موفقیت ذخیره شد.')}
                    className="bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-xl text-xs font-semibold shadow-md shadow-red-600/30 transition-all flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>ذخیره تغییرات</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* MODAL: ADD PRODUCT */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-slate-800 border border-slate-700 rounded-2xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700 mb-4">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-red-500" />
                <span>افزودن محصول جدید به کاتالوگ نووا</span>
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">نام کامل محصول *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="مثال: بتن‌کن ۴ شیار نووا مدل 2800"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-red-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">دسته‌بندی</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-red-500"
                  >
                    <option value="ابزار برقی و شارژی">ابزار برقی و شارژی</option>
                    <option value="ابزار دستی و عمومی">ابزار دستی و عمومی</option>
                    <option value="ابزار بادی و بنزینی">ابزار بادی و بنزینی</option>
                    <option value="ابزار اندازه‌گیری و دقیق">ابزار اندازه‌گیری و دقیق</option>
                    <option value="تجهیزات جوش و برش">تجهیزات جوش و برش</option>
                    <option value="کیف و جعبه ابزار">کیف و جعبه ابزار</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">موجودی انبار</label>
                  <input
                    type="number"
                    value={newStock}
                    onChange={(e) => setNewStock(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-red-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">قیمت با تخفیف (تومان) *</label>
                  <input
                    type="text"
                    required
                    value={newPrice}
                    onChange={(e) => setNewPrice(e.target.value)}
                    placeholder="مثال: 3450000"
                    dir="ltr"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 font-mono focus:outline-hidden focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">قیمت قبل تخفیف (تومان)</label>
                  <input
                    type="text"
                    value={newOriginalPrice}
                    onChange={(e) => setNewOriginalPrice(e.target.value)}
                    placeholder="مثال: 4200000"
                    dir="ltr"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 font-mono focus:outline-hidden focus:border-red-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">آدرس تصویر کالا (URL)</label>
                <input
                  type="url"
                  value={newImage}
                  onChange={(e) => setNewImage(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  dir="ltr"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">گارانتی</label>
                <input
                  type="text"
                  value={newWarranty}
                  onChange={(e) => setNewWarranty(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-red-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="isSpecial"
                  checked={newIsSpecial}
                  onChange={(e) => setNewIsSpecial(e.target.checked)}
                  className="w-4 h-4 rounded text-red-600 bg-slate-900 border-slate-700"
                />
                <label htmlFor="isSpecial" className="text-slate-200 cursor-pointer">
                  افزودن به ردیف پیشنهادهای شگفت‌انگیز (تخفیف ویژه)
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-700">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-xl text-xs shadow-md shadow-red-600/30"
                >
                  ثبت محصول نووا
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EDIT PRODUCT */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-slate-800 border border-slate-700 rounded-2xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700 mb-4">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-blue-400" />
                <span>ویرایش اطلاعات محصول</span>
              </h3>
              <button
                onClick={() => setEditingProduct(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditProduct} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">نام محصول</label>
                <input
                  type="text"
                  required
                  value={editingProduct.title}
                  onChange={(e) => setEditingProduct({ ...editingProduct, title: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-red-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">قیمت فروش (تومان)</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.price}
                    onChange={(e) => setEditingProduct({ ...editingProduct, price: parseInt(e.target.value, 10) || 0 })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 font-mono focus:outline-hidden focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">موجودی انبار</label>
                  <input
                    type="number"
                    value={editingProduct.stockCount}
                    onChange={(e) => setEditingProduct({ ...editingProduct, stockCount: parseInt(e.target.value, 10) || 0 })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-hidden focus:border-red-500"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="editSpecial"
                  checked={editingProduct.isSpecialOffer || false}
                  onChange={(e) => setEditingProduct({ ...editingProduct, isSpecialOffer: e.target.checked })}
                  className="w-4 h-4 rounded text-red-600 bg-slate-900 border-slate-700"
                />
                <label htmlFor="editSpecial" className="text-slate-200 cursor-pointer">
                  پیشنهاد شگفت‌انگیز
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-700">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-xs shadow-md shadow-blue-600/30"
                >
                  ذخیره تغییرات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
