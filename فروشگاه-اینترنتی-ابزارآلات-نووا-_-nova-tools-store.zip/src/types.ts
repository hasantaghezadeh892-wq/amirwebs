export interface Product {
  id: string;
  title: string;
  englishTitle?: string;
  category: string;
  categoryId: string;
  price: number;
  originalPrice: number;
  discountPercent: number;
  rating: number;
  reviewCount: number;
  image: string;
  inStock: boolean;
  stockCount: number;
  isSpecialOffer?: boolean; // پیشنهاد شگفت‌انگیز
  isBestSeller?: boolean;
  specs: {
    [key: string]: string;
  };
  features: string[];
  warranty: string;
  brand: string;
}

export interface Category {
  id: string;
  name: string;
  englishName: string;
  iconName: string;
  image: string;
  count: number;
}

export interface User {
  id: string;
  username: string;
  fullName: string;
  email?: string;
  role: 'admin' | 'user';
  authProvider: 'google' | 'credentials';
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  customerName: string;
  customerEmail: string;
  items: CartItem[];
  totalAmount: number;
  discountAmount: number;
  finalAmount: number;
  status: 'در حال پردازش' | 'ارسال شده' | 'تحویل شده' | 'لغو شده';
  date: string;
  shippingAddress: string;
  paymentMethod: 'درگاه آنلاین' | 'پرداخت در محل';
}

export interface DiscountCode {
  code: string;
  percent: number;
  maxAmount: number;
  minOrder: number;
}
