import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { Product, Category } from './types';
import { INITIAL_PRODUCTS, INITIAL_CATEGORIES } from './data/mockData';

import { Header } from './components/Header';
import { HeroSlider } from './components/HeroSlider';
import { TrustBadges } from './components/TrustBadges';
import { IncredibleOffers } from './components/IncredibleOffers';
import { CategoriesGrid } from './components/CategoriesGrid';
import { BannerGrid } from './components/BannerGrid';
import { ProductGrid } from './components/ProductGrid';
import { ProductDetailModal } from './components/ProductDetailModal';
import { AuthModal } from './components/AuthModal';
import { CartDrawer } from './components/CartDrawer';
import { AdminPanel } from './components/AdminPanel';
import { Footer } from './components/Footer';

const MainApp: React.FC = () => {
  const { currentView } = useAuth();

  // Products with LocalStorage persistence so Admin additions/edits persist!
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('nova_products_catalog');
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [categories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  useEffect(() => {
    localStorage.setItem('nova_products_catalog', JSON.stringify(products));
  }, [products]);

  const handleAddProduct = (newProd: Product) => {
    setProducts((prev) => [newProd, ...prev]);
  };

  const handleUpdateProduct = (updatedProd: Product) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === updatedProd.id ? updatedProd : p))
    );
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans selection:bg-red-500 selection:text-white" dir="rtl">
      {/* View Switch: Store or Admin Panel */}
      {currentView === 'admin' ? (
        <AdminPanel
          products={products}
          onAddProduct={handleAddProduct}
          onUpdateProduct={handleUpdateProduct}
          onDeleteProduct={handleDeleteProduct}
        />
      ) : (
        <>
          <Header
            products={products}
            onSelectProduct={setSelectedProduct}
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
          />

          <main className="flex-1">
            <HeroSlider onSelectCategory={setSelectedCategory} />
            <TrustBadges />
            <IncredibleOffers
              products={products}
              onSelectProduct={setSelectedProduct}
            />
            <CategoriesGrid
              categories={categories}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
            />
            <BannerGrid onSelectCategory={setSelectedCategory} />
            <ProductGrid
              products={products}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              onSelectProduct={setSelectedProduct}
            />
          </main>

          <Footer />
        </>
      )}

      {/* Global Modals & Drawers */}
      <AuthModal />
      <CartDrawer />
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <MainApp />
      </CartProvider>
    </AuthProvider>
  );
}
