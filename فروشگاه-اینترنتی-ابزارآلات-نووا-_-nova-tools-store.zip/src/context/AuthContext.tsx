import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  isAdmin: boolean;
  isAuthModalOpen: boolean;
  authModalTab: 'login' | 'signup';
  currentView: 'store' | 'admin';
  setCurrentView: (view: 'store' | 'admin') => void;
  openAuthModal: (tab?: 'login' | 'signup') => void;
  closeAuthModal: () => void;
  loginWithCredentials: (username: string, password: string) => Promise<{ success: boolean; message?: string }>;
  signupWithCredentials: (username: string, password: string, fullName?: string, email?: string) => Promise<{ success: boolean; message?: string }>;
  loginWithGoogle: () => Promise<{ success: boolean; message?: string }>;
  logout: () => void;
  allUsers: User[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_CREDENTIALS = {
  username: 'admin',
  password: '88142',
};

const DEFAULT_USERS: User[] = [
  {
    id: 'user-admin',
    username: 'admin',
    fullName: 'مدیر کل سیستم',
    email: 'admin@novatools.ir',
    role: 'admin',
    authProvider: 'credentials',
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'user-sample',
    username: 'ali_karimi',
    fullName: 'علی کریمی',
    email: 'ali.karimi@gmail.com',
    role: 'user',
    authProvider: 'credentials',
    createdAt: '2026-09-12T10:00:00Z',
  },
  {
    id: 'user-google-demo',
    username: 'hasan_taghezadeh',
    fullName: 'حسن تقوی‌زاده',
    email: 'HASANTAGHEZADEH892@gmail.com',
    role: 'user',
    authProvider: 'google',
    createdAt: '2026-10-10T12:00:00Z',
  },
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('nova_current_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [currentView, setCurrentView] = useState<'store' | 'admin'>(() => {
    try {
      const saved = localStorage.getItem('nova_current_user');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.role === 'admin') return 'admin';
      }
    } catch {
      // ignore
    }
    return 'store';
  });

  const [allUsers, setAllUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem('nova_all_users');
      return saved ? JSON.parse(saved) : DEFAULT_USERS;
    } catch {
      return DEFAULT_USERS;
    }
  });

  const [passwordsMap, setPasswordsMap] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem('nova_user_passwords');
      return saved ? JSON.parse(saved) : { admin: '88142', ali_karimi: '123456' };
    } catch {
      return { admin: '88142', ali_karimi: '123456' };
    }
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'signup'>('login');

  useEffect(() => {
    if (user) {
      localStorage.setItem('nova_current_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('nova_current_user');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('nova_all_users', JSON.stringify(allUsers));
  }, [allUsers]);

  useEffect(() => {
    localStorage.setItem('nova_user_passwords', JSON.stringify(passwordsMap));
  }, [passwordsMap]);

  const isAdmin = user?.role === 'admin';

  const openAuthModal = (tab: 'login' | 'signup' = 'login') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const loginWithCredentials = async (username: string, password: string): Promise<{ success: boolean; message?: string }> => {
    const cleanUsername = username.trim();

    // Check admin credentials specified by user: admin / 88142
    if (cleanUsername === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
      const adminUser: User = {
        id: 'user-admin',
        username: 'admin',
        fullName: 'مدیر کل سیستم',
        email: 'admin@novatools.ir',
        role: 'admin',
        authProvider: 'credentials',
        createdAt: new Date().toISOString(),
      };
      setUser(adminUser);
      setCurrentView('admin'); // Directly enters admin panel as requested!
      closeAuthModal();
      return { success: true, message: 'ورود موفق به پنل مدیریت نووا با دسترسی ادمین' };
    }

    // Check normal users
    const matchedUser = allUsers.find((u) => u.username.toLowerCase() === cleanUsername.toLowerCase());
    if (!matchedUser) {
      return { success: false, message: 'نام کاربری یا رمز عبور اشتباه است.' };
    }

    const savedPassword = passwordsMap[cleanUsername.toLowerCase()];
    if (savedPassword && savedPassword !== password) {
      return { success: false, message: 'نام کاربری یا رمز عبور اشتباه است.' };
    }

    setUser(matchedUser);
    if (matchedUser.role === 'admin') {
      setCurrentView('admin');
    } else {
      setCurrentView('store');
    }
    closeAuthModal();
    return { success: true, message: `خوش آمدید، ${matchedUser.fullName || matchedUser.username}` };
  };

  const signupWithCredentials = async (
    username: string,
    password: string,
    fullName?: string,
    email?: string
  ): Promise<{ success: boolean; message?: string }> => {
    const cleanUsername = username.trim().toLowerCase();

    if (cleanUsername.length < 3) {
      return { success: false, message: 'نام کاربری باید حداقل ۳ کاراکتر باشد.' };
    }

    if (password.length < 4) {
      return { success: false, message: 'رمز عبور باید حداقل ۴ کاراکتر باشد.' };
    }

    // Check if username already exists
    if (allUsers.some((u) => u.username.toLowerCase() === cleanUsername)) {
      return { success: false, message: 'این نام کاربری قبلاً ثبت شده است. لطفاً نام کاربری دیگری انتخاب کنید.' };
    }

    const newUser: User = {
      id: 'usr-' + Date.now(),
      username: cleanUsername,
      fullName: fullName?.trim() || cleanUsername,
      email: email?.trim() || `${cleanUsername}@example.com`,
      role: 'user',
      authProvider: 'credentials',
      createdAt: new Date().toISOString(),
    };

    setAllUsers((prev) => [newUser, ...prev]);
    setPasswordsMap((prev) => ({ ...prev, [cleanUsername]: password }));
    setUser(newUser);
    setCurrentView('store');
    closeAuthModal();

    return { success: true, message: 'ثبت‌نام شما با موفقیت انجام شد!' };
  };

  const loginWithGoogle = async (): Promise<{ success: boolean; message?: string }> => {
    // Simulated Google OAuth Flow
    const googleEmail = 'user.google@gmail.com';
    const googleUsername = 'google_user_' + Math.floor(1000 + Math.random() * 9000);
    const googleName = 'کاربر حساب گوگل';

    let existing = allUsers.find((u) => u.email === googleEmail || u.authProvider === 'google');
    if (!existing) {
      existing = {
        id: 'google-' + Date.now(),
        username: googleUsername,
        fullName: googleName,
        email: googleEmail,
        role: 'user',
        authProvider: 'google',
        createdAt: new Date().toISOString(),
      };
      setAllUsers((prev) => [existing!, ...prev]);
    }

    setUser(existing);
    setCurrentView('store');
    closeAuthModal();
    return { success: true, message: 'ورود موفق از طریق حساب گوگل' };
  };

  const logout = () => {
    setUser(null);
    setCurrentView('store');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAdmin,
        isAuthModalOpen,
        authModalTab,
        currentView,
        setCurrentView,
        openAuthModal,
        closeAuthModal,
        loginWithCredentials,
        signupWithCredentials,
        loginWithGoogle,
        logout,
        allUsers,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
