import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, Order, DiscountCode } from '../types';
import { INITIAL_ORDERS } from '../data/mockData';

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  totalItems: number;
  subtotal: number;
  discountAmount: number;
  shippingCost: number;
  finalTotal: number;
  appliedCoupon: DiscountCode | null;
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  orders: Order[];
  createOrder: (shippingAddress: string, customerName: string, customerEmail: string, paymentMethod: 'درگاه آنلاین' | 'پرداخت در محل') => Order;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
}

const VALID_COUPONS: DiscountCode[] = [
  { code: 'NOVA20', percent: 20, maxAmount: 800000, minOrder: 1000000 },
  { code: 'DIGINOVA', percent: 15, maxAmount: 500000, minOrder: 500000 },
  { code: 'WELCOME', percent: 10, maxAmount: 300000, minOrder: 200000 },
];

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('nova_cart_items');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<DiscountCode | null>(null);

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('nova_orders');
      return saved ? JSON.parse(saved) : INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  });

  useEffect(() => {
    localStorage.setItem('nova_cart_items', JSON.stringify(cartItems));
  }, [cartItems]);

  useEffect(() => {
    localStorage.setItem('nova_orders', JSON.stringify(orders));
  }, [orders]);

  const addToCart = (product: Product, quantity: number = 1) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCartItems([]);
    setAppliedCoupon(null);
  };

  const totalItems = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const subtotal = cartItems.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );

  let couponDiscount = 0;
  if (appliedCoupon) {
    const rawDiscount = (subtotal * appliedCoupon.percent) / 100;
    couponDiscount = Math.min(rawDiscount, appliedCoupon.maxAmount);
  }

  // Free shipping over 500,000 Tomans, otherwise 45,000 Tomans
  const shippingCost = subtotal > 500000 || subtotal === 0 ? 0 : 45000;
  const finalTotal = Math.max(0, subtotal - couponDiscount + shippingCost);

  const applyCoupon = (code: string) => {
    const clean = code.trim().toUpperCase();
    const coupon = VALID_COUPONS.find((c) => c.code === clean);
    if (!coupon) {
      return { success: false, message: 'کد تخفیف وارد شده معتبر نمی‌باشد.' };
    }
    if (subtotal < coupon.minOrder) {
      return {
        success: false,
        message: `حداقل مبلغ سفارش برای اعمال این کد تخفیف ${coupon.minOrder.toLocaleString('fa-IR')} تومان است.`,
      };
    }
    setAppliedCoupon(coupon);
    return { success: true, message: `کد تخفیف ${coupon.percent}٪ با موفقیت اعمال گردید.` };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
  };

  const createOrder = (
    shippingAddress: string,
    customerName: string,
    customerEmail: string,
    paymentMethod: 'درگاه آنلاین' | 'پرداخت در محل'
  ): Order => {
    const newOrder: Order = {
      id: 'ord-' + Date.now(),
      orderNumber: 'DKN-' + Math.floor(100000 + Math.random() * 900000),
      userId: 'usr-guest',
      customerName,
      customerEmail,
      items: [...cartItems],
      totalAmount: subtotal,
      discountAmount: couponDiscount,
      finalAmount: finalTotal,
      status: 'در حال پردازش',
      date: new Date().toISOString(),
      shippingAddress,
      paymentMethod,
    };

    setOrders((prev) => [newOrder, ...prev]);
    clearCart();
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status } : ord))
    );
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        totalItems,
        subtotal,
        discountAmount: couponDiscount,
        shippingCost,
        finalTotal,
        appliedCoupon,
        applyCoupon,
        removeCoupon,
        orders,
        createOrder,
        updateOrderStatus,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
